<!DOCTYPE>
<?php
//include("functions/functions.php");
session_start();
?>
<?php if(!isset($_SESSION['customer_emailll']))
{
    echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Sorry You are not Logged In!.')
        window.location.href='index.php'
        </SCRIPT>");
    echo "<script>window.open('index.php','_self')</script>";
}
 else {
     
 ?>

<html>
    <head>
        <title>PASSWORD FORGOT</title>
    </head>
    <body>
        <form align="center"  action="" method="POST">
        Email:<input type="email" name="email" placeholder="Enter your email" value="">
            <input type="submit" name="s" value="Sumbit">
        </form>
        
<?php
include("functions/functions.php");
global $con;
if(isset($_POST['s'])){
$emaill=$_POST['email'];
$select12="select * from `customer` where `customer_email`='$emaill'";  
$run_select12=mysqli_query($con,$select12);
if(mysqli_num_rows($run_select12)==1){
        while($ss=mysqli_fetch_array($run_select12)){
        $firstname1=$ss['firstname'];
        $email_code1=$ss['email_code'];
        $emaill=$ss['customer_email'];
       // send_mail_change_psw();
        
                        
                
$URL=" http://localhost:8081/sellerbuyer/activation.php?email=".$emaill."&email_code=".$email_code1." ";                          
//mailing function 	
$to    =  $emaill;
$subject = 'Password change';
$message = 'Thank you for registering'."\n\n";
			

$message.="Hello " ."$firstname1" . "\r\n\n" 
        . "You need to browse this URL with email and email code to change your password." ."\r\n\n"
        
        . "http://localhost:8081/sellerbuyer/new_password.php?email=" .$emaill. "&email_code=" .$email_code1. ""."\n\n"
       
        ."Seller Buyer";


$headers = 'From:shrikantkandel@gmail.com' . "\r\n" .
           'Reply-To:shrikantkandel@gmail.com' . "\r\n" .
           
           'X-Mailer: PHP/' . phpversion();

if(mail($to, $subject, $message, $headers)) {
      echo "<script>alert('Email sent successfully!Check your email!!!!!.')</script>";
   // echo 'Email sent successfully!Check your email and conform your email address.';
      echo "<script>window.open('index.php','_self')</script>";
} else {
    die('Failure: Email was not sent!');
} 

 

}
} 

 else {
     echo "Email not found";
}

}
else
{
    echo "Please submit your email";
}        
?> 
  
       
    </body>
</html>
                        <?php }?>