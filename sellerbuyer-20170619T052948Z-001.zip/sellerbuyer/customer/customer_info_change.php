<!DOCTYPE>
<?php
//include("functions/functions.php");
session_start();
?>
<?php if(!isset($_SESSION['customer_emailll']))
{
    echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Sorry You are not Logged In!.')
        window.location.href='../index.php'
        </SCRIPT>");
    echo "<script>window.open('../index.php','_self')</script>";
}
 else {
     
 ?>

<html>
    <head>
        <title>Customer Info</title>
        <link rel="stylesheet" href="styles/styles.css" media="all"/>
    <h3 align="center">Your Info</h3>
    </head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    
    
    <style>
        .form_content
        {
            width: 1050px;
            float: center;
            margin-top: 1px;
            margin-left: 120px;
          
        }
input[type=email], select {
    width: 50%;
    padding: 5px 5px;
    margin: 0px;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
input[type=text], select {
    width: 50%;
    padding: 5px 5px;
    margin: 0px;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
input[type=number], select {
    width: 50%;
    padding: 5px 5px;
    margin: 0px;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
input[type=password], select {
    width: 50%;
    padding: 5px 5px;
    margin: 0px;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
input[type=submit] {
    width: 50%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

div {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>
    <body>
         <div class="form_content">
             <form  align="center"  action="customer_info_change.php" method="post">
            
	<?php
//session_start();
global $con;
include("functions/functions.php");
$ip=getIp();
$select="select * from customer where customer_ip='$ip'";
$run_select=  mysqli_query($con, $select);
while($cus=  mysqli_fetch_array($run_select)){
    $firstname=$cus['firstname'];
    $lastname=$cus['lastname'];
    $email=$cus['customer_email'];
    $address=$cus['address'];
    $phone=$cus['phone'];
    $username=$cus['username'];
    $password=  trim($cus['password']);
    $_SESSION['username']=$username;

   
    
}
 
?>
		
        
                 <div><label>Firstname</label></br>
        <input type="text" name="firstname" class="form-control" placeholder="Firstname" value="<?php echo $firstname;?>"><br />
        <label>Lasetname</label></br><input type="text" name="lastname" class="form-control" placeholder="Lastname" value="<?php echo $lastname;?>"><br />
	<label>Email</label></br><input type="email" name="email" placeholder="Email" value="<?php echo $email;?>"><br/>
        <label>Address</label></br><input type="text" name="address" class="form-control" placeholder="Address" value="<?php echo $address;?>"><br/>
       <label>Phone</label></br><input type="number" name="phone" class="form-control" placeholder="Phone number" value="<?php echo $phone;?>"><br/>
       <label>Username</label></br><input type="text" name="username" class="form-control" placeholder="Username" value="<?php echo $_SESSION['username'];?>"><br/>
       <input type="submit" name="conform" value="Update">
        
        <?php
        if(isset($_POST['conform'])){
                
        $ufirstname = $_POST['firstname'];
        $ulastname = $_POST['lastname'];
	$uemail = $_POST['email'];
        $uaddress = $_POST['address'];
        $uphone = $_POST['phone'];
	$uusername = $_POST['username'];
        $update="update customer set firstname='$ufirstname',lastname='$ulastname',customer_email='$uemail', address='$uaddress',phone='$uphone',username='$uusername' where customer_ip='$ip'";
        $run_update=  mysqli_query($con, $update);
       // $insert_query="INSERT INTO customer(firstname,lastname,customer_email,address,phone,username ) VALUES ('$firstname','$lastname','$email','$address','$phone','$username')";	
        //$run_query=  mysqli_query($con, $insert_query); 
        if($run_update==TRUE){
         echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Succesfully Updated!.')
        window.location.href='customer_info_change.php'
        </SCRIPT>");
         
         //mailing function 	
$to    =  $email;
$subject = 'Your Account has been updated';
$message = 'Thank you for staying with us'."\n\n";
			

$message.="Hello " ."$firstname" . "\r\n\n" 
        . "Your informations are." ."\r\n\n"
        ."Firstname:"."$ufirstname"."\r\n\n"
        ."Lastname:"."$ulastname"."\r\n\n"
        ."Username:"."$uusername"."\r\n\n"
        ."Emai:"."$uemail"."\r\n\n"
        ."Phone:"."$uphone"."\r\n\n"
        ."Adress:"."$uaddress"."\r\n\n"
       ?>    
             
<?php 
$message.= "Seller Buyer"?>
      
   
 <?php

$headers = 'From:shrikantkandel@gmail.com' . "\r\n" .
           'Reply-To:shrikantkandel@gmail.com' . "\r\n" .
           
           'X-Mailer: PHP/' . phpversion();

if(mail($to, $subject, $message, $headers)) {
      echo "<script>alert('Email sent successfully!Check your email and conform your email address.')</script>";
   // echo 'Email sent successfully!Check your email and conform your email address.';
      echo "<script>window.open('index.php','_self')</script>";
} else {
    die('Failure: Email was not sent!');
}  


         
         
         
         
        }
       else {
        echo "Not Updated";
           }
        }
        ?>
    </div>
                
 <p>
        <a href="my_account.php" class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-chevron-left"></span> Left
        </a>
 </p>
             </form>

        </div>
    </body>
</html>

 <?php } ?>