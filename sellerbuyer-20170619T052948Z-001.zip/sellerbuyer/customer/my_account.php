<!DOCTYPE>
<?php
include("functions/functions.php");
session_start();
?>
<?php if(!isset($_SESSION['customer_emailll']))
{
    echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Sorry You are not Logged In!.')
        window.location.href='../index.php'
        </SCRIPT>");
    echo "<script>window.open('../index.php','_self')</script>";
}
 else {
     
 ?>



<html>
    <head>
        
        <meta charset="UTF-8">
        <title>Seller Buyer</title>
        
        <link rel="stylesheet" href="styles/styles.css" media="all"/>
        
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
<link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>   
   




    </head>
    <body>
        
        <!-- sab vanda mathi ko navigation -->
         <nav class="navbar navbar-inverse navbar-fixed-top">
      
        <div class="navbar-header">
            <a class="navbar-brand" href="../index.php">Seller Buyer Nepal Online shopping </a>
        </div>
        
          <form class="navbar-form navbar-right">
            <?php
                 
                 if(isset($_SESSION['customer_emailll']))
                       {
                     
                         echo "<b>Hi, You are logged in</b>";
                        
                       }
                 ?>
               <?php
                        if(!isset($_SESSION['customer_emailll']))
                        {
                           echo "<a href='checkout.php' style='color:red ; text-align:left ;'></a>";
                          
                        }
                        else
                        {
                           
                          // echo "<b>Hi,</b>".$_SESSION['customer_emailll']; 
                             ?>
                 <a class="btn btn-danger" href="logout.php" role="button"><span class="glyphicon glyphicon-off"></span></a>
                  
                            <?php
                        }
                        ?>
          </form>
      
      
    </nav>
       
        
         
        
        <div class="main_wrapper" >
            
            <div class="header_wrapper" > 
               <!-- <img id ="logo" src ="images/logo.gif"/>-->
                <img id="banner" src="images/banner.gif" />
                
            </div>
            
           
            <div class="menubar">
                <ul id="menu">
                    <li><a href="../index.php">HOME</a></li>
                    
                </ul>
                             
     </div>         
            
            <!--<div class="content_wrapper">-->
                <div id="content_area">       
                  <?php cart();?>  
                <div id="shopping_cart">
                    <span style="float: right"> <b style="color: greenyellow">Shopping cart</b>
                        Total Items:<b style="color: blue"><?php total_items();?></b> Total Price:<b style="color: blue">Rs.<?php total_price();?></b> 
                        <a href="cart.php">Go to Cart</a>
                    
                    </span>
                    
                </div> 
                   
                    
                    <div id="products_box">
                        <?php
                        $get_name="select customer_email from customer";
                         if(isset($_GET['change_my_info']))
                         {
                         include('customer_info_change.php');
                        // header('Location:customer_info_change.php');
                         }
                        else {}
                         
                      ?>
                        
                        
                    </div>
                 </div>
            
            <?php
             if(isset($_GET['logout']))
                    {
                    include ("customer_logout.php");
                    }
              if(isset($_GET['delete']))
                    {
                    include ("customer_delete.php");
                    }
               
                    
            
            ?>
            
            
            
            

                <div id="sidebar">
                    <div id="sidebar_title">My Account</div>
                    <ul id="products">
                        <li><a href="#">My Cart</a></li>
                        <li><a href="#">My Info</a></li>
                        <li><a href="customer_info_change.php?change_my_info">Edit My Info</a></li>
                        <li><a href="#">Change Password</a></li>
                        <li><a href="my_account.php?delete">Delete Account</a></li>
                        <li><a href="my_account.php?logout">Log Out</a></li>
                        
                        
                        
                   </ul>
           </div>
            </div>
                 <div class="footer">
                <ul id="footerr">
                
                    <li><a href="about_us.php">About Us</a></li>
                    <li><a href="conditions.php">Terms and Conditions</a></li>
                    <li><a href="contact_us.php">Contact Us</a></li>
                    <li><a href="support.php">Support</a></li>
                    
                </ul>
            </div>
              
        <!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    </body>
</html>
<?php } ?>