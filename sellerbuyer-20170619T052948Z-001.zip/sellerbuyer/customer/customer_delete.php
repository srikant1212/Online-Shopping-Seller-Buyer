<?php
if(isset($_SESSION['customer_emailll']))
{
    global $con;
    $ip=  getIp();
    
    $delete_customer="DELETE FROM customer WHERE customer_ip='$ip'";
    $run_delete_customer=  mysqli_query($con, $delete_customer);
    if($run_delete_customer==1)
    {
        echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Your Account has been deleted!.')
        window.location.href='../index.php'
        </SCRIPT>");
    echo "<script>window.open('../index.php','_self')</script>";
    }
    
    
}
?>

