<?php
session_start();
include('includes/db.php');
//include('functions/functions.php');
  $total=0;
    global $con;
    function getkIp() {
    $ip = $_SERVER['REMOTE_ADDR'];
 
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
 
    return $ip;
}
   $ip=  getkIp();
   $sel_price= "select * from cart where ip_address='$ip'";
    $email=$_SESSION['customer_emailll'];
   // $sel_price= "select * from cart where customer_email='$email'";
    $run_price= mysqli_query($con, $sel_price);
    while($p_price=  mysqli_fetch_array($run_price)){ 
        $pro_id=$p_price['p_id'];
        if($pro_id < 10){
        $pro_price="select * from products where product_id='$pro_id'";}
        else {
        $pro_price="select * from clothproducts where product_id='$pro_id'";}
        $run_pro_price=  mysqli_query($con, $pro_price);
        while ($pp_price=  mysqli_fetch_array($run_pro_price)){
            $product_price=array($pp_price['product_price']);
            $product_name=$pp_price['product_title'];
            $values=  array_sum($product_price);
            $total=$total+$values;
            $tax=100;
            $psc=50;
            $pdc=50;
            $amt=5000;
            $tAmt = $amt + $tax + $psc + $pdc;
            
        }
         
    }
?>
<form action="http://dev.esewa.com.np/epay/main" method="POST">
<input value="<?php echo $tAmt;?>" name="tAmt" type="text">
<input value="<?php echo  $amt;?>" name="amt" type="text">
<input value="<?php echo  $tax;?>" name="txAmt" type="text">
<input value="<?php echo $psc;?>" name="psc" type="text">
<input value="<?php echo  $pdc;?>" name="pdc" type="text">
<input value="eSewa_himalayan" name="scd" type="text">
<input value="<?php echo $pro_id;?>" name="pid" type="text">
<!--<input value="http://modernsansar.com/sellerbuyer/success.php?q=su" type="hidden" name="su">-->
<!--<input value="http://modernsansar.com/sellerbuyer/cancel.php?q=fu" type="hidden" name="fu">-->
<input value="success.php?q=su" type="hidden" name="su">
<input value="cancel.php?q=fu" type="hidden" name="fu">
<input value="Submit" type="submit">
</form>