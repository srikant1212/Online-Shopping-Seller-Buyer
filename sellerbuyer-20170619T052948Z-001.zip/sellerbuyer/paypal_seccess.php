<?php
session_start();
?>
<html>
    <head>
    <title>Payment successful</title>
    </head>
    <body>
        <h2>Hi, <?php echo $_SESSION['customer_emailll'];?></h2>
        <h3>Your payment was successfully done!!</h3>
        <h3><a href="#">Go to your account</a></h3>
    </body>
</html>