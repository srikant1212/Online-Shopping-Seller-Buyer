<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Login form</title>
    <link rel="stylesheet" href="styles/style_login.css">
  
  </head>

  <body>

    
<div class="container">
	<section id="content">
            <form  action="checkout.php" method="post">
			<h1>Login Form</h1>
			<div>
				<input type="text" placeholder="Enter Username" required="" name="uname"  id="username" />
			</div>
			<div>
				<input type="password" placeholder="Enter Password" required="" name="pass" id="password" />
			</div>
<?php
global $con;
require ('db.php');
if (isset($_POST['submit'])){
$password=  mysqli_escape_string($con, $_POST['pass']);
$username=$_POST['uname'];
$password=md5($_POST['pass']);
if (!$_POST['uname'] | !$_POST['pass'])
 {
echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('You did not complete all of the required fields')
        window.location.href='checkout.php'
        </SCRIPT>");
exit();
  }
  
  


$sql= mysqli_query($con,"SELECT * FROM `customer` WHERE `username` = '$username' AND `password` = '$password' and `active`=1");
$email="select `customer_email` from `customer` WHERE `username` = '$username' AND `password` = '$password' and `active`=1 "; 
//$insert_query="INSERT INTO logged_user(firstname,lastname,customer_email,email_code,address,phone,username,password,customer_ip ) VALUES ('$firstname','$lastname','$email','$email_code','$address','$phone','$username','$password','$ip')";	
//$run_query=  mysqli_query($con, $insert_query);    
if(mysqli_num_rows($sql) > 0)
{
    $_SESSION['customer_emailll']=$email;
echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Login Succesfully!.')
        window.location.href='checkout.php'
        </SCRIPT>");        
exit();
}

 





else{
    
echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Either Wrong info or Not email activation.Please re-enter.')
        window.location.href='checkout.php'
        </SCRIPT>");
exit();
}




}
else{
}
?>


			<div>
                            <input type="submit" name="submit" value="login"  />
                                <a href="checkout.php?forgot_pass">Lost your password?</a>
                                <?php 
                                if(isset($_GET['forgot_pass'])){
                                    include('forgot_pass.php');
                                }
                                else {}
                                ?>
                                <a href="customer_register.php">Register</a>


			</div>
		</form><!-- form -->
		
	</section><!-- content -->
</div><!-- container -->

    
        <script src="js/index.js"></script>

    
    
  </body>
</html>
        
