<!DOCTYPE>
<?php
include("functions/functions.php");
?>

<html>
    <head>
        
        <meta charset="UTF-8">
        <title>Seller Buyer</title>
        
        <link rel="stylesheet" href="styles/styles.css" media="all"/>
        
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
<link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>   
     </head>
    <body>
        
        <!-- sab vanda mathi ko navigation -->
         <nav class="navbar navbar-inverse navbar-fixed-top">
      
        <div class="navbar-header">
            <a class="navbar-brand" href="index.php">Seller Buyer Nepal Online shopping </a>
        </div>
        
             <form class="navbar-form navbar-right" method="post">
                  <?php
         //  if(!isset($_POST['submit']))
             if(!isset($_SESSION['customer_emailll']))
           {
           ?>
            <div class="form-group">
                <input type="text" placeholder="Enter Username" name="uname" class="form-control">
            </div>
            <div class="form-group">
                <input type="password" placeholder="Password"  name="pass" class="form-control">
            </div>
            
     
        <!-- <button  type="submit" class="btn btn-success"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>
             <a href='checkout.php' style='color:white;'>Log In</a>
            </button>-->
          
             <button  type="submit" class="btn btn-success" name="submit"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>
             Log In
            </button>
             
           <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>
             <a href="customer_register.php"  style='color:white;'>Sign Up</a>
            </button>
           <?php } ?>
             <?php
             global $con;
require ('db.php');
if (isset($_POST['submit'])){
$password=  mysqli_escape_string($con, $_POST['pass']);
$username=$_POST['uname'];
$password=md5($_POST['pass']);
if (!$_POST['uname'] | !$_POST['pass'])
 {
echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('You did not complete all of the required fields')
        window.location.href='checkout.php'
        </SCRIPT>");
exit();
     }
$sql= mysqli_query($con,"SELECT * FROM `customer` WHERE `username` = '$username' AND `password` = '$password'");
$email=mysqli_query($con,"select `customer_email` from `customer` WHERE `username` = '$username' AND `password` = '$password'");

            
if(mysqli_num_rows($sql) > 0)
{
    $_SESSION['customer_emailll']=$email;
    echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Login Succesfully!.')
        window.location.href='all_products.php'
        </SCRIPT>");
   
exit();
}
else{
    
echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Wrong username password combination.Please re-enter.')
        window.location.href='all_products.php'
        </SCRIPT>");
exit();
}
}
else{
}
             ?>
             
                 <?php
                 
                 if(isset($_SESSION['customer_emailll']))
                       {
                     
                         echo "<b>Hi, You are logged in</b>";
                         //$_SESSION['test'] = 42;
                       //  $test = 43;
                        // echo $_SESSION['test'];
                         //echo $email;
                       //  echo $_SESSION['customer_emailll'];
                       }
                 ?>
                <?php
                        if(!isset($_SESSION['customer_emailll']))
                        {
                           echo "<a href='checkout.php' style='color:red ; text-align:left ;'>Login</a>";
                        }
                        else
                        {
                             //echo "<b>Hi,</b>".$_SESSION['customer_emailll'];
                           
                             echo "<a href='logout.php' style='color:red;'>Logout</a>";
                        }
                        ?>
             </form>
                       
          
       <!--/.navbar-collapse -->
      
    </nav>
       <!-- sab vanda mathi ko navigation -->  
        
        
        
        
        <div class="main_wrapper" >
            
            <div class="header_wrapper" > 
               <!-- <img id ="logo" src ="images/logo.gif"/>-->
                <img id="banner" src="images/banner.gif" />
                
            </div>
            
           
            <div class="menubar">
                <ul id="menu">
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="all_products.php">ALL PRODUCT</a></li>
                    <li><a href="cart.php">SHOPPING CART</a></li>
                    <li><a href="customer/my_account.php">MY ACCOUNT</a></li>
                  
                    <li><a href="contact_us.php">CONTACT US</a></li>
                </ul>
                
                <!--
                <div id="form">
                    <form method="get" action="results.php" enctype="multipart/formdata">
                        <input type="text" name="user_query" placeholder="Search a product"/>
                        <input type="submit" name="search" value="search"/>
                    </form>
                </div>
                    
                -->
            
             
 <!--            
<ul class="nav nav-tabs">
    
                    <li><a href="#">HOME</a></li>
                    <li><a href="#">ALL PRODUCT</a></li>
                    <li><a href="#">SHOPPING CART</a></li>
  <li role="presentation" class="dropdown">
    <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
      Sign Up <span class="caret"></span>
    </a>
    <ul class="dropdown-menu">
    <li><a href="#">Action</a></li>
    <li><a href="#">Another action</a></li>
    <li><a href="#">Something else here</a></li>
      <li><a href="#">MY ACCOUNT</a></li> 
    </ul>
  </li>
       <li><a href="#">CONTACT US</a></li>-->
 

            
             
             
             
<form class="navbar-form navbar-right" action="results.php" role="search">
  <div class="form-group">
    <input type="text" class="form-control" placeholder="Search a product">
  </div>
  <button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
</form>
      
  </ul>           
             
     </div>         
            
            <!--<div class="content_wrapper">-->
                <div id="content_area">       
                  <?php cart();?>  
                <div id="shopping_cart">
                    <span style="float: right"> <b style="color: greenyellow">Shopping cart</b>
                        Total Items:<b style="color: blue"><?php total_items();?></b> Total Price:<b style="color: blue">Rs.<?php total_price();?></b> 
                        <a href="cart.php">Go to Cart</a>
                    
                    </span>
                    
                </div>
                   
                    
                    <div id="products_box">
                        <?php

                           $get_pro="select * from products ";
                          $run_pro=  mysqli_query($con, $get_pro);
                          while ($row_pro =mysqli_fetch_array($run_pro))
                          {
                              $pro_id=$row_pro['product_id'];
                              $pro_cat=$row_pro['product_cata'];
                              $pro_brand=$row_pro['product_brand'];
                              $pro_price=$row_pro['product_price'];
                              $pro_title=$row_pro['product_title'];
                              $pro_image=$row_pro['product_image'];

                              echo "
                                <div id='single_product_kolagi'>

                                  <h3>$pro_title</h3> 
                                      <img src='admin_area/products_images/$pro_image' width='200' height='200'/>
                                          <p><b> Rs $pro_price</b></p>
                                          <a href='details.php? pro_id=$pro_id' style='float :left;'>Details</a>
                                          <a href='index.php?pro_id=$pro_id'><botton style='float:right'>Add to Bucket</botton></a>   


                              </div>  


                              ";
                          }

                       ?>
                        
                        
                    </div>
                        
                
                </div>

                <div id="sidebar">
                    <div id="sidebar_title">Women's Fashion</div>
                    <ul id="products">
                        <?php
                        //getWoman_Fashion();
                        getclothcata();
                        ?>
                   </ul>
                    <div id="sidebar_title">Clothing Brand</div>
                    <ul id="products">
                        <?php
                       // getMen_Fashion();
                        getclothbrand();
                        ?>
                   </ul>
                   
                  <!--static 
                  <div id="sidebar_title">Mobiles and Tablets</div>
                    <ul id="products">
                        <li><a href="#">Macbooks</a></li>
                        <li><a href="#">Ultraboks</a></li>
                        <li><a href="#">Android</a></li>
                        <li><a href="#">Dell</a></li>
                        <li><a href="#">HP</a></li>
                        <li><a href="#">Acer</a></li>     
                   </ul>
                  !-->
                      <div id="sidebar_title">Categories</div>
                    <ul id="products">
                       <?php
                       getCats();
                       ?> 
                   </ul>
                    <div id="sidebar_title">Brands</div>
                    <ul id="products">
                       <?php
                       getBrands();
                       ?> 
                   </ul>
               
               
                
            </div>
            </div>
                
                
            
            
           
               <div class="footer">
                <ul id="footerr">
                
                    <li><a href="about_us.php">About Us</a></li>
                    <li><a href="conditions.php">Terms and Conditions</a></li>
                    <li><a href="contact_us.php">Contact Us</a></li>
                    <li><a href="support.php">Support</a></li>
                    
                </ul>
            </div><!-- 
              </div>
              <div class="well well-lg">
                <!--  <ul id="footerr">
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Terms and Conditions</a></li>
                    <li><a href="#">Support</a></li>  
                  </ul>
             
                    <address>
                    <strong style="text-align:center">About Me</strong><br>
                     Imadol-09<br>
                     Kathmandu, Nepal<br>
                     <abbr title="Phone">Mb no.:</abbr> 981193500
                    <a href="mailto:#">srikant_kandel@yahoo.com</a>
                    </address>  -->
              </div>
                            
      
        <!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    </body>
</html>
