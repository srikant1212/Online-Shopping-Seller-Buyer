<!DOCTYPE>
<?php
session_start();
include("functions/functions.php");
include ("includes/db.php");
        $_SESSION['firstname']="";
        $_SESSION['lastname']='';
        $_SESSION['customer_email']='';
        $_SESSION['address']='';
        $_SESSION['phone']='';
        $_SESSION['username']='';
        $_SESSION['password']='';
?>

<html>
    <head>
        
        <meta charset="UTF-8">
        <title>Seller Buyer</title>
        
        <link rel="stylesheet" href="styles/styles.css" media="all"/>
        
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
<link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>   
<!-- username check garna -->   
<script>
function checkusername(){
	var status = document.getElementById("usernamestatus");
	var u = document.getElementById("uname").value;
	if(u != ""){
		status.innerHTML = 'checking...';
		var hr = new XMLHttpRequest();
		hr.open("POST", "name_check.php", true);
		hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		hr.onreadystatechange = function() {
			if(hr.readyState == 4 && hr.status == 200) {
				status.innerHTML = hr.responseText;
			}
		}
        var v = "name2check="+u;
        hr.send(v);
	}
}
function checkphone(){
	var status = document.getElementById("phonestatus");
	var u = document.getElementById("ph").value;
	if(u != ""){
		status.innerHTML = 'checking...';
		var hr = new XMLHttpRequest();
		hr.open("POST", "check_phone_number.php", true);
		hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		hr.onreadystatechange = function() {
			if(hr.readyState == 4 && hr.status == 200) {
				status.innerHTML = hr.responseText;
			}
		}
        var v = "phone2check="+u;
        hr.send(v);
	}
}
</script>



    </head>
    <body>
        
        <!-- sab vanda mathi ko navigation -->
          <nav class="navbar navbar-inverse navbar-fixed-top">
      
        <div class="navbar-header">
            <a class="navbar-brand" href="index.php">Seller Buyer Nepal Online shopping </a>
        </div>
        
         <form class="navbar-form navbar-right">
          
         
                <?php
                        if(!isset($_SESSION['customer_emailll']))
                        {
                           echo "<a href='checkout.php' style='color:red ; text-align:left ;'></a>";
                          
                        }
                        else
                        {
                           
                          // echo "<b>Hi,</b>".$_SESSION['customer_emailll']; 
                             ?>
                 <a class="btn btn-danger" href="logout.php" role="button"><span class="glyphicon glyphicon-off"></span></a>
                  
                            <?php
                        }
                        ?>
             </form>
                       
          
       <!--/.navbar-collapse -->
      
    </nav>
       <!-- sab vanda mathi ko navigation -->  
        
        
        <div class="main_wrapper" >
            
            <div class="header_wrapper" > 
               <!-- <img id ="logo" src ="images/logo.gif"/>-->
                <img id="banner" src="images/banner.gif" />
                
            </div>
            
           
            <div class="menubar">
                <ul id="menu">
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="all_products.php">ALL PRODUCT</a></li>
                    <li><a href="cart.php">SHOPPING CART</a></li>
                    <li><a href="customer/my_account.php">MY ACCOUNT</a></li>
                  
                    <li><a href="contact_us.php">CONTACT US</a></li>
                </ul>
                
                <!--
                <div id="form">
                    <form method="get" action="results.php" enctype="multipart/formdata">
                        <input type="text" name="user_query" placeholder="Search a product"/>
                        <input type="submit" name="search" value="search"/>
                    </form>
                </div>
                    
                -->
            
             
 <!--            
<ul class="nav nav-tabs">
    
                    <li><a href="#">HOME</a></li>
                    <li><a href="#">ALL PRODUCT</a></li>
                    <li><a href="#">SHOPPING CART</a></li>
  <li role="presentation" class="dropdown">
    <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
      Sign Up <span class="caret"></span>
    </a>
    <ul class="dropdown-menu">
    <li><a href="#">Action</a></li>
    <li><a href="#">Another action</a></li>
    <li><a href="#">Something else here</a></li>
      <li><a href="#">MY ACCOUNT</a></li> 
    </ul>
  </li>
       <li><a href="#">CONTACT US</a></li>-->
 

            
             
             
             
<form class="navbar-form navbar-right" action="results.php" role="search">
  <div class="form-group">
    <input type="text" class="form-control" placeholder="Search a product">
  </div>
  <button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
</form>
      
  </ul>           
             
     </div>         
            
            <!--<div class="content_wrapper">-->
                <div id="content_area">       
                  <?php cart();?>  
                <div id="shopping_cart">
                    <span style="float: right"> <b style="color: greenyellow">Shopping cart</b>
                        Total Items:<b style="color: blue"><?php total_items();?></b> Total Price:<b style="color: blue">Rs.<?php total_price();?></b> 
                        <a href="cart.php">Go to Cart</a>
                    
                    </span>
                    
                </div>
                   <!-- sign up form-->
      <form action="customer_register.php" method="POST" role="form">
	<?php 
					    
        global $con;
        if (isset($_POST['signup'])) {
        $ip=  getIp();
       
       
	$firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
	$email = $_POST['email'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];
	$username = $_POST['username'];
	$password = md5($_POST['password']);
	$confirm_password = md5($_POST['confirm_password']);
        $email_code=  md5($_POST['username'])+ microtime();
        $_SESSION['firstname']=$firstname;
        $_SESSION['lastname']=$lastname;
        $_SESSION['customer_email']=$email;
        $_SESSION['address']=$address;
        $_SESSION['phone']=$phone;
        $_SESSION['username']=$username;
        $_SESSION['password']=$password;
        $_SESSION['conform_password']=$confirm_password;
       

if(isset($_POST["name2check"]) && $_POST["name2check"] != ""){
    include_once 'includes/db.php';
    $username = preg_replace('#[^a-z0-9]#i', '', $_POST['name2check']); 
    //$sql_uname_check = mysql_query("SELECT customer_id FROM customer WHERE username='$username' LIMIT 1"); 
    $sql_uname_check = "SELECT customer_id FROM customer WHERE username='$username' LIMIT 1";
	$run_sql=mysqli_query($con,$sql_uname_check);
	$uname_check = mysqli_num_rows($run_sql);
    if (strlen($username) < 4) {
	    echo '4 - 15 characters please';
	    exit();
    }
	if (is_numeric($username[0])) {
	    echo 'First character must be a letter';
	    exit();
    }
    if ($uname_check < 1) {
	    echo '<strong>' . $username . '</strong> is OK';
	    exit();
    } else {
	    echo '<strong>' . $username . '</strong> is taken';
	    exit();
    }
}

//phone number check start

if(isset($_POST["phone2check"]) && $_POST["phone2check"] != ""){
    include_once 'includes/db.php';
    $phone1 = preg_replace('#[a-z]#i','', $_POST['phone2check']); 
     $phone = preg_replace('#[^0-9]#i','', $_POST['phone2check']); 
    //$sql_uname_check = mysql_query("SELECT customer_id FROM customer WHERE username='$username' LIMIT 1"); 
    $sql_phone_check = "SELECT customer_id FROM customer WHERE phone='$phone' LIMIT 1";
	$run_sql=mysqli_query($con,$sql_phone_check);
	$phone_check = mysqli_num_rows($run_sql);
        $count_num=strlen($phone) ;
        //if(strlen($phone1)<15)
        //{
          //echo ' Integer number please';
     //exit();   
       // }
    if ($count_num== 10)  {
         if ($phone_check < 1) {
	   
                if($phone[0]=='9' && $phone[1]=='8')
                {
                     echo '<strong>' . $phone . '</strong> is OK';
	             exit();
                }
                else
                {
                      echo 'Enter phone number starting with 98..';
	              exit(); 
                }
            }
            else {
	    echo '<strong>' . $phone . '</strong> is taken';
	    exit();
    }
    }
 else {
     echo '10 characters please';
     exit();
 }
        
    
    
    
    
}

//phone number check end


	if (empty($firstname) || empty($lastname) || empty($email) || empty($username) || empty($password) || empty($confirm_password) || empty($phone)|| empty($address)) 
         {
            ?>
	<div class="alert alert-danger" role="alert">
	<?php echo 'Fill all the content of form!';?>
	  </div>
              <?php 
	}
       else{
	  //username check gareko                  
        $select_username="select username from customer where username='$username'";
        $run_select_username=  mysqli_query($con, $select_username);
        
        if(mysqli_num_rows($run_select_username)>0){
               ?>
		<div class="alert alert-danger" role="alert">
			<?php    echo 'username match!';?>
		 </div>
			   <?php
        }           
        
        //email check gareko
        $select_email="select customer_email from customer where customer_email='$email'";
        $run_select_email=  mysqli_query($con, $select_email);
        if(mysqli_num_rows($run_select_email)>0){
               ?>
		<div class="alert alert-danger" role="alert">
			<?php    echo 'Email match!';?>
		 </div>
			   <?php
                    
        
        }
        //password checking 
      if ($err = pc_passwordcheck($_REQUEST['username'],$_REQUEST['password'])) {
          ?>
          <div class="alert alert-danger" role="alert">
			<?php    echo "Bad password: $err";?>
		 </div>
          <?php
   
      }
          if($password!=$confirm_password) 
            { ?>
		<div class="alert alert-danger" role="alert">
                    <?php    echo 'Password donot match!';?>
                        
                    </div>
                    <audio hidden="" controls="controls" autoplay="autoplay">
                        <source src="sound/0758.ogg" type="audio/ogg">
                        <source src="sound/0758.mp3" type="audio/mpeg">
                    Your browser does not support the audio element.
                    </audio>
		 
        <?php }
  
 
            if($password==$confirm_password && mysqli_num_rows($run_select_email)==0 && mysqli_num_rows($run_select_username)==0 && $_POST['password'] && $_POST['confirm_password'] ){
              
                   
                 //$query=mysql_query("INSERT INTO customer(firstname,lastname,email,address,phone,username,password ) VALUES ('$firstname','$lastname','$email','$address','$phone','$username','$password')");
		$insert_query="INSERT INTO customer(firstname,lastname,customer_email,email_code,address,phone,username,password,customer_ip ) VALUES ('$firstname','$lastname','$email','$email_code','$address','$phone','$username','$password','$ip')";	
                $run_query=  mysqli_query($con, $insert_query); 
                
                $sel_cart= "select * from cart where ip_address='$ip' ";
                $run_cart=  mysqli_query($con, $sel_cart);
                $check_cart=  mysqli_num_rows($run_cart);
                if($check_cart == 0)
                {
                   // $_SESSION['customer_emailll'] = $email;
                    echo "<script>alert('Account has been created succesfully')</script>";
                    //echo "<script>window.open('customer/my_account.php','_self')</script>";
                  // echo "<script>window.open('sendmail.php','_self')</script>";
                    //send_mail();
                   
                    
                }
                else
                    
                    {
                    
                   // $_SESSION['customer_emailll'] = $email;
                    echo "<script>alert('Account has been created succesfully')</script>";
                    
                     //echo "<script>window.open('checkout.php','_self')</script>";
                   
                   // send_mail();
                    // echo "<script>window.open('sendmail.php','_self')</script>";
                     
                    
                    }
                
                
                
$URL=" http://localhost:8081/sellerbuyer/activation.php?email=".$email."&email_code=".$email_code." ";                          
//mailing function 	
$to    =  $email;
$subject = 'Email Conformaion';
$message = 'Thank you for registering'."\n\n";
			

$message.="Hello " ."$firstname" . "\r\n\n" 
        . "You need to browse this URL with email and email code to activate your account." ."\r\n\n"
        
        . "http://localhost:8081/sellerbuyer/activation.php?email=" .$email. "&email_code=" .$email_code. ""."\n\n"
       ?>    
             
<?php 
$message.= "Seller Buyer"?>
      
   
 <?php

$headers = 'From:shrikantkandel@gmail.com' . "\r\n" .
           'Reply-To:shrikantkandel@gmail.com' . "\r\n" .
           
           'X-Mailer: PHP/' . phpversion();

if(mail($to, $subject, $message, $headers)) {
      echo "<script>alert('Email sent successfully!Check your email and conform your email address.')</script>";
   // echo 'Email sent successfully!Check your email and conform your email address.';
      echo "<script>window.open('index.php','_self')</script>";
} else {
    die('Failure: Email was not sent!');
}  



/*mail(
     'shrikantkandel@gmail.com',
     'Works!',
     'An email has been generated from your localhost, congratulations!');*/



                 
               /*if ($run_query==1) {
                     ?>
				<div class="alert alert-success" role="alert">
				<?php echo 'Thank you for signing up'; ?>
							     
				</div>
				 <?php
				}else{ ?>
				<div class="alert alert-danger" role="alert">
				<?php echo 'Error while signing up. Try again!';?>
							      
				 </div>
				<?php
				     
				  }*/
                                   
                                   
                
			          }
            
		         	}
		  	}
                        ?>

          
			<div  class="formgroup">
			<br/>
                        
                       
                         <input type="text" name="firstname" class="form-control" placeholder="Firstname" value="<?php echo $_SESSION['firstname'];?>"><br />
			<input type="text" name="lastname" class="form-control" placeholder="Lastname" value="<?php echo $_SESSION['lastname'];?>"><br />
			<input type="email" name="email" class="form-control" placeholder="Email" value="<?php echo $_SESSION['customer_email'];?>"><br />
                        <input type="text" name="address" class="form-control" placeholder="Address" value="<?php echo $_SESSION['address'];?>"><br />
                       <!-- <input type="number" name="phone" class="form-control" placeholder="Phone number" value="<?php //echo $_SESSION['phone'];?>"><br />-->
			<!--<input type="text" name="username" class="form-control" placeholder="Username" value="<?php //echo $_SESSION['username'];?>"><br />-->
			<input type="number" name="phone" id="ph" class="form-control"  onBlur="checkphone()" placeholder="Phone number" maxlength="10">
                        <!-- <input type="number" name="phone" class="form-control" placeholder="Phone number" value=""><br />-->
                        <span id="phonestatus"></span></br>
                        <input type="text" name="username" id="uname" onBlur="checkusername()" class="form-control"  maxlength="15" placeholder="Username" value="<?php echo $_SESSION['username'];?>">
                        <span id="usernamestatus"></span></br>
                        <input type="password" name="password" class="form-control" placeholder="Password" value=""><br />
			<input type="password" name="confirm_password" class="form-control" placeholder="Confirm Password" value=""><br />
			<button type="submit" name="signup" class="btn btn-success">Sign Up</button>
						
			</div>
       
		</form>
              </div>

                <div id="sidebar">
                    <div id="sidebar_title">Clothing Category</div>
                     <ul id="products">
                        <?php
                        //getWoman_Fashion();
                        getclothcata();
                        ?>
                   </ul>
                    <div id="sidebar_title">Clothing Brand</div>
                    <ul id="products">
                        <?php
                       // getMen_Fashion();
                        getclothbrand();
                        ?>
                   </ul>
                   
                  <!--static 
                  <div id="sidebar_title">Mobiles and Tablets</div>
                    <ul id="products">
                        <li><a href="#">Macbooks</a></li>
                        <li><a href="#">Ultraboks</a></li>
                        <li><a href="#">Android</a></li>
                        <li><a href="#">Dell</a></li>
                        <li><a href="#">HP</a></li>
                        <li><a href="#">Acer</a></li>     
                   </ul>
                  !-->
                      <div id="sidebar_title">Categories</div>
                    <ul id="products">
                       <?php
                       getCats();
                       ?> 
                   </ul>
                    <div id="sidebar_title">Brands</div>
                    <ul id="products">
                       <?php
                       getBrands();
                       ?> 
                   </ul>
               
               
                
            </div>
            </div>
                
                
            
            
           
               <div class="footer">
                <ul id="footerr">
                
                    <li><a href="about_us.php">About Us</a></li>
                    <li><a href="conditions.php">Terms and Conditions</a></li>
                    <li><a href="contact_us.php">Contact Us</a></li>
                    <li><a href="support.php">Support</a></li>
                    
                </ul>
            </div>
             
                            
      
        <!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    </body>
</html>
