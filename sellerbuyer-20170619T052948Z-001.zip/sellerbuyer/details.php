<!DOCTYPE>
<?php
include("functions/functions.php");
session_start();
 $_SESSION['qty']="";
?>

<html>
    <head>
        
        <meta charset="UTF-8">
        <title>Seller Buyer</title>
        
        <link rel="stylesheet" href="styles/styles.css" media="all"/>
        
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
<link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>   
   




    </head>
<style>
.pic{
	width:200px;
	height:200px;
        float: left;
        background-color: whitesmoke;
        margin-top: 42px;
        margin-bottom: 50px;
        border: 2px solid black;
        
        
        
}
.picbig{
	/*position: absolute;*/
        float: left;
        border: 1px solid black;
	width:0px;/*big picture lai hidden garako*/
	-webkit-transition:width 0.3s linear 0s;
	transition:width 0.3s linear 0s;
	z-index:10;
}
.pic:hover + .picbig{ /* addition of two sibling element*/
	width:570px;
        height:440px; 
}
</style>
    <body>
        
        <!-- sab vanda mathi ko navigation -->
           <!-- sab vanda mathi ko navigation -->
         <nav class="navbar navbar-inverse navbar-fixed-top">
      
        <div class="navbar-header">
            <a class="navbar-brand" href="index.php">Seller Buyer Nepal Online shopping </a>
        </div>
        
           <form class="navbar-form navbar-right" method="post">
                  <?php
         //  if(!isset($_POST['submit']))
             if(!isset($_SESSION['customer_emailll']))
           {
           ?>
            <div class="form-group">
                <input type="text" placeholder="Enter Username" name="uname" class="form-control">
            </div>
            <div class="form-group">
                <input type="password" placeholder="Password"  name="pass" class="form-control">
            </div>
            
     
        <!-- <button  type="submit" class="btn btn-success"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>
             <a href='checkout.php' style='color:white;'>Log In</a>
            </button>-->
          
             <button  type="submit" class="btn btn-success" name="submit"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>
             Log In
            </button>
             
           <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>
             <a href="customer_register.php"  style='color:white;'>Sign Up</a>
            </button>
           <?php } ?>
             <?php
             global $con;
require ('db.php');
if (isset($_POST['submit'])){
$password=  mysqli_escape_string($con, $_POST['pass']);
$username=$_POST['uname'];
$password=md5($_POST['pass']);
if (!$_POST['uname'] | !$_POST['pass'])
 {
echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('You did not complete all of the required fields')
        window.location.href='checkout.php'
        </SCRIPT>");
exit();
     }

$sql= mysqli_query($con,"SELECT * FROM `customer` WHERE `username` = '$username' AND `password` = '$password' AND `active`=1");
$email="select * from `customer` WHERE `username` = '$username' AND `password` = '$password' AND `active`=1 "; 
$run_email=  mysqli_query($con, $email); 

 
if(mysqli_num_rows($sql) > 0)
{
    $_SESSION['customer_emailll']=$email;
    echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Login Succesfully!.')
        window.location.href='index.php'
        </SCRIPT>");
    
   /* $select_emaill="select email from logged_user where active =1";
    $run_select_emaill=  mysqli_query($con, $select_emaill);
    
if(mysqli_num_rows($run_select_emaill) ==0){    
$insert_query="INSERT INTO logged_user(firstname,lastname,customer_email,email_code,address,phone,username,password,customer_ip ) VALUES ('$firstname','$lastname','$email','$email_code','$address','$phone','$username','$password','$ip')";	
$run_query=  mysqli_query($con, $insert_query); 
} */   
exit();
}
else{
    
echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Wrong username password combination.Please re-enter.')
        window.location.href='index.php'
        </SCRIPT>");
exit();
}
}
else{
}
                          
             
                 

               //if(isset($_GET['success']) ===TRUE && empty($_GET['success'])===TRUE)
               // if(isset($_GET['activated'])===TRUE)
                

                 if(isset($_SESSION['customer_emailll']))
                       {
                     
                        // echo "<b>Hi, " .$email . "  You are logged in</b>";
                     echo "<b>".$_SESSION['customer_email']."</b>";
                      
                        
                       }
                       
                  
              ?>
                
                   <?php
                        if(!isset($_SESSION['customer_emailll']))
                        {
                           echo "<a href='checkout.php' style='color:red ; text-align:left ;'></a>";
                          
                        }
                        else
                        {
                           
                          // echo "<b>Hi,</b>".$_SESSION['customer_emailll']; 
                             ?>
                 <a class="btn btn-danger" href="logout.php" role="button"><span class="glyphicon glyphicon-off"></span></a>
                  
                            <?php
                        }
                        ?>
                
             </form>
                       
          
  
          
       <!--/.navbar-collapse -->
      
    </nav>
       <!-- sab vanda mathi ko navigation -->   
        
        
        
        <div class="main_wrapper">
            
            <div class="header_wrapper" > 
               <!-- <img id ="logo" src ="images/logo.gif"/>-->
                <img id="banner" src="images/banner.gif" />
                
            </div>
            
           
            <div class="menubar">
                <ul id="menu">
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="all_products.php">ALL PRODUCT</a></li>
                    <li><a href="cart.php">SHOPPING CART</a></li>
                    <li><a href="customer/my_account.php">MY ACCOUNT</a></li>
                  
                    <li><a href="contact_us.php">CONTACT US</a></li>
                </ul>
                
                <!--
                <div id="form">
                    <form method="get" action="results.php" enctype="multipart/formdata">
                        <input type="text" name="user_query" placeholder="Search a product"/>
                        <input type="submit" name="search" value="search"/>
                    </form>
                </div>
                    
                -->
            
             
 <!--            
<ul class="nav nav-tabs">
    
                    <li><a href="#">HOME</a></li>
                    <li><a href="#">ALL PRODUCT</a></li>
                    <li><a href="#">SHOPPING CART</a></li>
  <li role="presentation" class="dropdown">
    <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
      Sign Up <span class="caret"></span>
    </a>
    <ul class="dropdown-menu">
    <li><a href="#">Action</a></li>
    <li><a href="#">Another action</a></li>
    <li><a href="#">Something else here</a></li>
      <li><a href="#">MY ACCOUNT</a></li> 
    </ul>
  </li>
       <li><a href="#">CONTACT US</a></li>-->
 

            
             
             
             
<form class="navbar-form navbar-right" action="results.php" role="search">
  <div class="form-group">
    <input type="text" class="form-control" placeholder="Search a product">
  </div>
  <button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
</form>
      
  </ul>           
             
     </div>         
            
            <div class="content_wrapper">
                <div id="content_area">
                    
                    
               <?php cart_for_details();
               cart_for_details_cloth() ;?>  
                <div id="shopping_cart">
                    <span style="float: right"> <b style="color: greenyellow">Shopping cart</b>
                        Total Items:<b style="color: blue"><?php total_items();?></b> Total Price:<b style="color: blue">Rs.<?php total_price();?></b> 
                        <a href="cart.php">Go to Cart</a>
                        
                        
                    
                    </span>
                    
                </div>
                    
                    <div id="products_box">
                        <?php
                        if( $_SESSION['electronics']==='11'){
                        //elctronics samanclick garda cloth ko details herna lai banako

                        if(isset($_GET['pro_id'])){
                            $product_iid=$_GET['pro_id'];
                            
                            $get_pro="select * from products where product_id=$product_iid";
                            $run_pro=  mysqli_query($con, $get_pro);
                            while ($row_pro =mysqli_fetch_array($run_pro))
                            {
                                $pro_id=$row_pro['product_id'];
                                $pro_price=$row_pro['product_price'];
                                $pro_title=$row_pro['product_title'];
                                $pro_image=$row_pro['product_image'];
                                $pro_desc=$row_pro['product_desc'];
                            
                                echo "
                                  <div id='single_product_kolagi'>

                                    <h3>$pro_title</h3> 
                                        
                                            
                                             <p><b> Rs $pro_price</b></p>
                                                <p>$pro_desc</p>
                                            <button><a href='index.php'style='float :left;'>Back</a></button></br></br>
                                                    <button><a href='details.php?add_cart=$pro_id'><botton style='float:left'>Add to Bucket</a></button></br>
                                    


                                </div> 
                                <img class='pic' src='admin_area/products_images/$pro_image'/ alt=''>
                                <img class='picbig' src='admin_area/products_images/$pro_image' alt=''/>

                                ";
                               //  include ("zoom_image.php");
                            }
                            }
                            
                        }
                        else{}
                        if( $_SESSION['cloth']=='12'){//cloth click garda cloth ko details herna lai banako
                            if(isset($_GET['pro_id'])){
                            $product_iid=$_GET['pro_id'];
                            
                            $get_pro="select * from clothproducts where product_id=$product_iid";
                            $run_pro=  mysqli_query($con, $get_pro);
                            while ($row_pro =mysqli_fetch_array($run_pro))
                            {
                                $pro_id=$row_pro['product_id'];
                                $pro_price=$row_pro['product_price'];
                                $pro_title=$row_pro['product_title'];
                                $pro_image=$row_pro['product_image'];
                                $pro_desc=$row_pro['product_desc'];
                            
                                echo "
                                  <div id='single_product_kolagi'>

                                    <h3>$pro_title</h3> 
                                        
                                            
                                             <p><b> Rs $pro_price</b></p>
                                                <p>$pro_desc</p>
                                                    <button><a href='index.php'style='float :left;'>Back</a></button></br></br>
                                                    <button><a href='index.php?add_cart=$pro_id' style='float:left'>Add to Bucket</a></button></br>
                                    
                                            


                                </div>  
                                <img class='pic' src='admin_area/products_images/$pro_image'/ alt=''>
                                <img class='picbig' src='admin_area/products_images/$pro_image' alt=''/>

                                ";
                               //  include ("zoom_image.php");
                            }
                            }
                            }
                            else{}
                            ?>
                       
                        
                        
                     
                       
                        
                    </div>
                        
                
                </div>
                
                
                
                
                <div id="sidebar">
                    <div id="sidebar_title">Women's Fashion</div>
                    <ul id="products">
                        <?php
                        //getWoman_Fashion();
                        getclothcata();
                        ?>
                   </ul>
                    <div id="sidebar_title">Clothing Brand</div>
                    <ul id="products">
                        <?php
                       // getMen_Fashion();
                        getclothbrand();
                        ?>
                   </ul>
                   
                 <!--   <div id="sidebar_title">Mobiles and Tablets</div>
                    <ul id="products">
                        <li><a href="#">Macbooks</a></li>
                        <li><a href="#">Ultraboks</a></li>
                        <li><a href="#">Android</a></li>
                        <li><a href="#">Dell</a></li>
                        <li><a href="#">HP</a></li>
                        <li><a href="#">Acer</a></li>     
                   </ul>-->
                      <div id="sidebar_title">Categories</div>
                    <ul id="products">
                       <?php
                       getCats();
                       ?> 
                   </ul>
                    <div id="sidebar_title">Brands</div>
                    <ul id="products">
                       <?php
                       getBrands();
                       ?> 
                   </ul>
               
               
                
            </div>
            </div>
                
                
            
            
           
              <!--  <div class="footer">
                <ul id="footerr">
                
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Terms and Conditions</a></li>
                    <li><a href="#">Contact Us</a></li>
                    <li><a href="#">Support</a></li>
                    
                </ul>
            </div> -->
              </div>
              <div class="footer">
                  <ul id="footerr">
                      <li><a href="about_us.php">About Us</a></li>
                    <li><a href="#">Terms and Conditions</a></li>
                    <li><a href="contact_us.php">Contact Us</a></li>
                    <li><a href="#">Support</a></li>  
                  </ul>
    </div>
                            
      
        <!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    </body>
</html>
