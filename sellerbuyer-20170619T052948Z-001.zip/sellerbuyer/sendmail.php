<?php
/*
$to    =  "srikantkandel@gmail.com";
$subject = 'Email Conformaion';
$message = 'Thank you for registering';
//$message.="Hello" ."$firstname"
  //      . "You need to click this link to activate your account."
  //      . "http://localhost:8081/sellerbuyer/activation.php?email=" .$to ." &email_code= ".$email_code." ";
             
$headers = 'From: shrikantkandel@gmail.com' . "\r\n" .
           'Reply-To: shrikantkandel@gmail.com' . "\r\n" .
           
           'X-Mailer: PHP/' . phpversion();

if(mail($to, $subject, $message, $headers)) {
    echo 'Email sent successfully!Check your email and conform your email address.';
} else {
    die('Failure: Email was not sent!');
}  

*/

if(mail(
     'srikantkandel@gmail.com',
     'Works!',
     'An email has been generated from your localhost, congratulations!'))
{
echo "works";
}
 else {
    echo "not";    
}

?>