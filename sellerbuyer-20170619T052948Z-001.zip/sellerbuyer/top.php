
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link href="navcss.css" rel="stylesheet" type="text/css" />
</head>
<STYLE TYPE="text/css">

#menu1 { display : none }
#menu2 { display : none }
#menu3 { display : none }

A:link {color:black; text-decoration:none}
A:hover {color:blue; text-decoration:underline}

</STYLE>
<body>
    <TABLE BORDER="0">

<TD VALIGN="top" Width="200">

<SPAN onMouseOver="document.all.menu1.style.display = 'block'" 
onMouseOut="document.all.menu1.style.display = 'block'"> 

Goodies Tutorials<BR>

</SPAN>

<SPAN ID="menu1" onClick="document.all.menu1.style.display = 'none'">

<A HREF="/tutors/frame1.html">Frames</A><BR>
<A HREF="/tutors/tbl.html">Tables</A><BR>
<A HREF="/beyond/dhtml.html">DHTML</A><BR>
<A HREF="/tutors/forms.html">Forms</A>

</SPAN>

</TD>
</TABLE>
</body>
</html>
