<?php
//session_start();
$con = mysqli_connect("localhost", "root", "", "sellerbuyer_2");

//error show garna ko lagi 
if(mysqli_connect_errno())
{
    echo 'Failed to connect'.mysqli_connect_error();
}
//ip address ko lagi
function getIp() {
    $ip = $_SERVER['REMOTE_ADDR'];
 
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
 
    return $ip;
}

//cart ko lagi
function cart()
{
    if(isset($_GET['add_cart']))
    {
     global $con;
     $ip=  getIp();
     $pro_id=$_GET['add_cart'];
     $check_pro="select * from cart where ip_address='$ip' and p_id='$pro_id'";
    $run_check=  mysqli_query($con, $check_pro);   
    if(mysqli_num_rows($run_check)>0)
    {
        echo '';
    }
 else {
    $insert_pro="insert into cart (p_id,ip_address) values ('$pro_id','$ip')"  ;
    $run_pro=  mysqli_query($con, $insert_pro);
    echo "<script>window.open('index.php','_self')</script>";
          
    }
}

}
function cart_for_details()
{
    if(isset($_GET['add_cart']))
    {
     global $con;
     $ip=  getIp();
     $pro_id=$_GET['add_cart'];
     $check_pro="select * from cart where ip_address='$ip' and p_id='$pro_id'";
    $run_check=  mysqli_query($con, $check_pro);   
    if(mysqli_num_rows($run_check)>0)
    {
        echo '';
    }
 else {
    $insert_pro="insert into cart (p_id,ip_address) values ('$pro_id','$ip')"  ;
    $run_pro=  mysqli_query($con, $insert_pro);
    echo "<script>window.open('details.php','_self')</script>";
          
    }
}

}
function cart_for_details_cloth()
{
    if(isset($_GET['add_cart']))
    {
     global $con;
     $ip=  getIp();
     $pro_id=$_GET['add_cart'];
     $check_pro="select * from cart where ip_address='$ip' and p_id='$pro_id'";
    $run_check=  mysqli_query($con, $check_pro);   
    if(mysqli_num_rows($run_check)>0)
    {
        echo '';
    }
 else {
    $insert_pro="insert into cart (p_id,ip_address) values ('$pro_id','$ip')"  ;
    $run_pro=  mysqli_query($con, $insert_pro);
    echo "<script>window.open('details.php','_self')</script>";
          
    }
}

}
//total cart ma items lina ko lagi 
function total_items()
{
    if(isset($_GET['add_cart']))
    {
        global $con;
        $ip=  getIp();
        $get_items="select * from cart where ip_address='$ip'";
        $run_items=mysqli_query($con, $get_items);
        $count_items=  mysqli_num_rows($run_items);
    }
 else {
        global $con;
        $ip=  getIp();
        $get_items="select * from cart where ip_address='$ip'";
        $run_items=  mysqli_query($con, $get_items);
        $count_items=  mysqli_num_rows($run_items);
 }
echo $count_items;
    
}
//total price calculation
function total_price()
{
    $total=0;
    global $con;
    $ip=  getIp();
    $sel_price= "select * from cart where ip_address='$ip'";
    $run_price= mysqli_query($con, $sel_price);
    while($p_price=  mysqli_fetch_array($run_price)){ 
        $pro_id=$p_price['p_id'];
        if($pro_id < 10){
        $pro_price="select * from products where product_id='$pro_id'";}
        else {
        $pro_price="select * from clothproducts where product_id='$pro_id'";}
        $run_pro_price=  mysqli_query($con, $pro_price);
        while ($pp_price=  mysqli_fetch_array($run_pro_price)){
            $product_price=array($pp_price['product_price']);  
            $values=  array_sum($product_price);
            $total=$total+$values;
            
        }
         
    }
    echo $total;
    
    
}



//getting categories
function getCats(){
    //$_SESSION['electronics']='11';//elctronics samanclick garda cloth ko details herna lai banako
    
    global $con;
    $get_cats="SELECT * FROM  `categories`";
    $run_cats=mysqli_query($con,$get_cats);
    while($row_cats=  mysqli_fetch_array($run_cats))
    {
        /* @var $cata_id type */
        $cata_id=$row_cats['cata_id'];
        /* @var $cata_title type */
        $cata_title=$row_cats['cata_title'];
        echo "<li><a href='index.php?cat=$cata_id'>$cata_title</a></li>";
    }
    
}

//getting brandss
function getBrands(){
  //$_SESSION['electronics']='11';//elctronics samanclick garda cloth ko details herna lai banako
    
    global $con;
    $get_brands="SELECT * FROM  `brand`";
    $run_brands=mysqli_query($con,$get_brands);
    while($row_brands=  mysqli_fetch_array($run_brands))
    {
        /* @var $brand_id type */
        $brand_id=$row_brands['brand_id'];
        /* @var $brand_title type */
        $brand_title=$row_brands['brand_title'];
        echo "<li><a href='index.php?brand=$brand_id'>$brand_title</a></li>";
    }
    
}
//getting cloths
function getclothcata(){
    global $con;
   // $_SESSION['cloth']='12';//cloth click garda cloth ko details herna lai banako
    $get_brands="SELECT * FROM  `cloth_category`";
    $run_brands=mysqli_query($con,$get_brands);
    while($row_brands=  mysqli_fetch_array($run_brands))
    {
        /* @var $brand_id type */
        $cloth_cata_id=$row_brands['cloth_cata_id'];
        /* @var $brand_title type */
        $cloth_cata_title=$row_brands['cloth_cata_title'];
        echo "<li><a href='index.php?cloth_cata=$cloth_cata_id'>$cloth_cata_title</a></li>";
    }
    
}
function getclothbrand(){
    global $con;
    //$_SESSION['cloth']='12';//cloth click garda cloth ko details herna lai banako
    $get_brands="SELECT * FROM  `cloth_brand`";
    $run_brands=mysqli_query($con,$get_brands);
    while($row_brands=  mysqli_fetch_array($run_brands))
    {
        /* @var $brand_id type */
        $cloth_brand_id=$row_brands['cloth_brand_id'];
        /* @var $brand_title type */
        $c_brand_title=$row_brands['cloth_brand_title'];
        echo "<li><a href='index.php?cloth_brand=$cloth_brand_id'>$c_brand_title</a></li>";
    }
    
}
function getproduct()
{
    if(!isset($_GET['cat'])){
        if(!isset($_GET['brand'])){
            if(!isset($_GET['cloth_cata'])){
                if(!isset($_GET['cloth_brand'])){
                    
             
        
    
    global $con;
    $get_pro="select * from products  order by RAND() LIMIT 0,12";
   // $get_pro="SELECT * from products JOIN clothproducts on(products.product_id=clothproducts.product_id)";
    
   // $get_pro="select * from products ,clothproducts";// where products.product_id=clothproducts.product_id";
    //$get_pro="SELECT c.* , p.* FROM products c INNER JOIN clothproducts p on(c.product_id=p.product_id)";
    $run_pro=  mysqli_query($con, $get_pro);
    while ($row_pro =mysqli_fetch_array($run_pro))
    {
        $pro_id=$row_pro['product_id'];
        $pro_cat=$row_pro['product_cata'];
        $pro_brand=$row_pro['product_brand'];
        $pro_price=$row_pro['product_price'];
        $pro_title=$row_pro['product_title'];
        $pro_image=$row_pro['product_image'];
        
        echo "
          <div id='single_product_kolagi'>
          
            <h3>$pro_title</h3> 
                <img src='admin_area/products_images/$pro_image' width='200' height='199'/>
                    <p><b> Rs $pro_price</b></p>
                     
  <button style='float :left;'><a href='details.php?pro_id=$pro_id' >Details</a></button>
 <button style='float:right'><a href='index.php?add_cart=$pro_id' >Add to Bucket</a></button>


        </div>  


        ";
    }
        }
    }
}
    }
}

//catagories ma click garda tyaha vako items fetch garna ko lagi
function getcatproduct()
{
    if(isset($_GET['cat'])){
       
    $cat_id=$_GET['cat'];    
    $_SESSION['electronics']='11';//elctronics samanclick garda cloth ko details herna lai banako
    global $con;
    $get_cat_pro="select * from products where product_cata='$cat_id'";
    $run_cat_pro=  mysqli_query($con, $get_cat_pro);
    $counts_cat=  mysqli_num_rows($run_cat_pro);
    if($counts_cat==0)
    {
        echo '<h2>No items in this categories </h2>';
    }
    
    while ($row_cat_pro =mysqli_fetch_array($run_cat_pro))
    {
        $pro_id=$row_cat_pro['product_id'];
        $pro_cat=$row_cat_pro['product_cata'];
        $pro_brand=$row_cat_pro['product_brand'];
        $pro_price=$row_cat_pro['product_price'];
        $pro_title=$row_cat_pro['product_title'];
        $pro_image=$row_cat_pro['product_image'];
        
        echo "
          <div id='single_product_kolagi'>
          
            <h3>$pro_title</h3> 
                <img src='admin_area/products_images/$pro_image' width='200' height='200'/>
                    <p><b> Rs $pro_price</b></p>
                    <a href='details.php? pro_id=$pro_id' style='float :left;'>Details</a>
                    <a href='index.php?add_cart=$pro_id'><botton style='float:right'>Add to Bucket</botton></a>   


        </div>  


        ";
    }
 }
}

//brand ma click garda tyaha vako items fetch garna ko lagi
function getbrandproduct()
{
     
    if(isset($_GET['brand'])){
    $_SESSION['electronics']='11';//elctronics samanclick garda cloth ko details herna lai banako
    $brand_id=$_GET['brand'];    
    
    global $con;
    $get_brand_pro="select * from products where product_brand='$brand_id'";
    $run_brand_pro=  mysqli_query($con, $get_brand_pro);
    
    $counts_brand=  mysqli_num_rows($run_brand_pro);
    if($counts_brand==0)
    {
        echo '<h2>No items in this brands   </h2>';
    }
    
    
    while ($row_brand_pro =mysqli_fetch_array($run_brand_pro))
    {
        $pro_id=$row_brand_pro['product_id'];
        $pro_cat=$row_brand_pro['product_cata'];
        $pro_brand=$row_brand_pro['product_brand'];
        $pro_price=$row_brand_pro['product_price'];
        $pro_title=$row_brand_pro['product_title'];
        $pro_image=$row_brand_pro['product_image'];
        
        echo "
          <div id='single_product_kolagi'>
          
            <h3>$pro_title</h3> 
                <img src='admin_area/products_images/$pro_image' width='200' height='200'/>
                    <p><b> Rs $pro_price</b></p>
                    <a href='details.php? pro_id=$pro_id' style='float :left;'>Details</a>
                    <a href='index.php?add_cart=$pro_id'><botton style='float:right'>Add to Bucket</botton></a>   


        </div>  


        ";
    }
 }
}






//cloth_brand ma click garda tyaha vako items fetch garna ko lagi
function get_cloth_brand_product()
{
   
    if(isset($_GET['cloth_brand'])){
    $_SESSION['cloth']='12';//cloth samanclick garda cloth ko details herna lai banako   
    $brand_id=$_GET['cloth_brand'];    
    
    global $con;
   $get_brand_pro="select * from clothproducts where product_brand='$brand_id'";
    //$get_brand_pro="select * from products where product_brand='$brand_id'";
    $run_brand_pro=  mysqli_query($con, $get_brand_pro);
    
    $counts_brand=  mysqli_num_rows($run_brand_pro);
    if($counts_brand==0)
    {
        echo '<h2>No items in this brands   </h2>';
    }
    
    
    while ($row_brand_pro =mysqli_fetch_array($run_brand_pro))
    {
        $pro_id=$row_brand_pro['product_id'];
        $pro_cat=$row_brand_pro['product_cata'];
        $pro_brand=$row_brand_pro['product_brand'];
        $pro_price=$row_brand_pro['product_price'];
        $pro_title=$row_brand_pro['product_title'];
        $pro_image=$row_brand_pro['product_image'];
        
        echo "
          <div id='single_product_kolagi'>
          
            <h3>$pro_title</h3> 
                <img src='admin_area/products_images/$pro_image' width='200' height='200'/>
                    <p><b> Rs $pro_price</b></p>
                    <a href='details.php? pro_id=$pro_id' style='float :left;'>Details</a>
                    <a href='index.php?add_cart=$pro_id'><botton style='float:right'>Add to Bucket</botton></a>   


        </div>  


        ";
    }
 }
}
function get_cloth_cata_product()
//catagories ma click garda tyaha vako items fetch garna ko lagi
{
    if(isset($_GET['cloth_cata'])){
    $_SESSION['cloth']='12';//cloth samanclick garda cloth ko details herna lai banako
    $cat_id=$_GET['cloth_cata'];    
    
    global $con;
    $get_cat_pro="select * from clothproducts where product_cata='$cat_id'";
   // $get_cat_pro="select * from products where product_cata='$cat_id'";

    $run_cat_pro=  mysqli_query($con, $get_cat_pro);
    $counts_cat=  mysqli_num_rows($run_cat_pro);
    if($counts_cat==0)
    {
        echo '<h2>No items in this categories </h2>';
    }
    
    while ($row_cat_pro =mysqli_fetch_array($run_cat_pro))
    {
        $pro_id=$row_cat_pro['product_id'];
        $pro_cat=$row_cat_pro['product_cata'];
        $pro_brand=$row_cat_pro['product_brand'];
        $pro_price=$row_cat_pro['product_price'];
        $pro_title=$row_cat_pro['product_title'];
        $pro_image=$row_cat_pro['product_image'];
        
        echo "
          <div id='single_product_kolagi'>
          
            <h3>$pro_title</h3> 
                <img src='admin_area/products_images/$pro_image' width='200' height='200'/>
                    <p><b> Rs $pro_price</b></p>
                    <a href='details.php? pro_id=$pro_id' style='float :left;'>Details</a>
                    <a href='index.php?add_cart=$pro_id'><botton style='float:right'>Add to Bucket</botton></a>   
 
                                    

        </div>  


        ";
    }
 }
}
function send_mail()
{
    
$to    = $email;
$subject = 'Email Conformaion';
$message = 'Thank you for registering
			click here to login localhost:8081/sellerbuyer';

$headers = 'From: shrikantkandel@gmail.com' . "\r\n" .
           'Reply-To: shrikantkandel@gmail.com' . "\r\n" .
           'X-Mailer: PHP/' . phpversion();

if(mail($to, $subject, $message, $headers)) {
    echo 'Email sent successfully!';
} else {
    die('Failure: Email was not sent!');
}  
}

//searching ko laagi
function get_search_result(){
    global $con;
    if(isset($_POST['s'])){
    if(!isset($_GET['cat'])){
        if(!isset($_GET['brand'])){
            if(!isset($_GET['cloth_cata'])){
                if(!isset($_GET['cloth_brand'])){
                   // php code to search data in mysql database and set it in input text
    // search_term to search
    $search_term = $_POST['s'];
    // mysql search query
   //$query = "SELECT * FROM `products` WHERE  `product_title` = '$search_term%' OR `product_title` = '$search_term'";
    $query = "SELECT * FROM `products` WHERE  `product_keywords` LIKE '$search_term%' OR `product_title` LIKE '$search_term%'";
    $result = mysqli_query($con, $query);
    // if search_term exist 
    if(mysqli_num_rows($result) > 0)
    {
   // $get_pro="select * from products ";
    //$run_pro=  mysqli_query($con, $get_pro);
    
    while ($row_pro =mysqli_fetch_array($result))
    {
        $pro_id=$row_pro['product_id'];
        $pro_cat=$row_pro['product_cata'];
        $pro_brand=$row_pro['product_brand'];
        $pro_price=$row_pro['product_price'];
        $pro_title=$row_pro['product_title'];
        $pro_image=$row_pro['product_image'];
        
        echo "
          <div id='single_product_kolagi'>
          
            <h3>$pro_title</h3> 
                <img src='admin_area/products_images/$pro_image' width='200' height='200'/>
                    <p><b> Rs $pro_price</b></p>
                    <a href='details.php? pro_id=$pro_id' style='float :left;'>Details</a>
                    <a href='index.php?add_cart=$pro_id'><botton style='float:right'>Add to Bucket</botton></a>   


        </div>  


        ";
    }} 
    else {
        /*echo "<h1>Sorry dear!!</h1> "
        . "<h2>Your choice is not found in our seller buyer system.</h2></br>"
        . "<h3 style='color:blue'>So please try to type product category</h3></br>"
            ."<h4>If you want <b style='color:red'>Samsung brand</b> mobile then type</h4>"
            ."<h5 style='color:red'>mobile</h5>";*/
    }
    }} }}
    // if the serach_term not exist
    // show a message and clear inputs
   /* 
    
    
    mysqli_free_result($result);
    mysqli_close($con);
    
*/
    }}
    
    
    
    
//password checking
    function pc_passwordcheck($user,$pass) {
    $word_file = '/usr/share/dict/words';
    
    $lc_pass = strtolower($pass);
    // also check password with numbers or punctuation subbed for letters
    $denum_pass = strtr($lc_pass,'5301!','seoll');
    $lc_user = strtolower($user);

    // the password must be at least six characters
    if (strlen($pass) < 6) {
        return 'The password is too short.';
    }

    // the password can't be the username (or reversed username) 
    if (($lc_pass == $lc_user) || ($lc_pass == strrev($lc_user)) ||
        ($denum_pass == $lc_user) || ($denum_pass == strrev($lc_user))) {
        return 'The password is based on the username.';
    }

    // count how many lowercase, uppercase, and digits are in the password 
    $uc = 0; $lc = 0; $num = 0; $other = 0;
    for ($i = 0, $j = strlen($pass); $i < $j; $i++) {
        $c = substr($pass,$i,1);
        if (preg_match('/^[[:upper:]]$/',$c)) {
            $uc++;
        } elseif (preg_match('/^[[:lower:]]$/',$c)) {
            $lc++;
        } elseif (preg_match('/^[[:digit:]]$/',$c)) {
            $num++;
        } else {
            $other++;
        }
    }

    // the password must have more than two characters of at least 
    // two different kinds 
    $max = $j - 2;
    if ($uc > $max) {
        return "The password has too many upper case characters.";
    }
    if ($lc > $max) {
        return "The password has too many lower case characters.";
    }
    if ($num > $max) {
        return "The password has too many numeral characters.";
    }
    if ($other > $max) {
        return "The password has too many special characters.";
    }

    // the password must not contain a dictionary word 
    if (is_readable($word_file)) {
        if ($fh = fopen($word_file,'r')) {
            $found = false;
            while (! ($found || feof($fh))) {
                $word = preg_quote(trim(strtolower(fgets($fh,1024))),'/');
                if (preg_match("/$word/",$lc_pass) ||
                    preg_match("/$word/",$denum_pass)) {
                    $found = true;
                }
            }
            fclose($fh);
            if ($found) {
                return 'The password is based on a dictionary word.';
            }
        }
    }

    return false;
}

//searching for cloths
function get_search_cloth_result(){
    global $con;
    if(isset($_POST['s'])){
    if(!isset($_GET['cat'])){
        if(!isset($_GET['brand'])){
            if(!isset($_GET['cloth_cata'])){
                if(!isset($_GET['cloth_brand'])){
                   // php code to search data in mysql database and set it in input text
    // search_term to search
    $search_term = $_POST['s'];
    // mysql search query
   //$query = "SELECT * FROM `products` WHERE  `product_title` = '$search_term%' OR `product_title` = '$search_term'";
    $query = "SELECT * FROM `clothproducts` WHERE  `product_keywords` LIKE '$search_term%' OR `product_title` LIKE '$search_term%'";
    $result = mysqli_query($con, $query);
    // if search_term exist 
    if(mysqli_num_rows($result) > 0)
    {
   // $get_pro="select * from products ";
    //$run_pro=  mysqli_query($con, $get_pro);
    
    while ($row_pro =mysqli_fetch_array($result))
    {
        $pro_id=$row_pro['product_id'];
        $pro_cat=$row_pro['product_cata'];
        $pro_brand=$row_pro['product_brand'];
        $pro_price=$row_pro['product_price'];
        $pro_title=$row_pro['product_title'];
        $pro_image=$row_pro['product_image'];
        
        echo "
          <div id='single_product_kolagi'>
          
            <h3>$pro_title</h3> 
                <img src='admin_area/products_images/$pro_image' width='200' height='200'/>
                    <p><b> Rs $pro_price</b></p>
                    <a href='details.php? pro_id=$pro_id' style='float :left;'>Details</a>
                    <a href='index.php?add_cart=$pro_id'><botton style='float:right'>Add to Bucket</botton></a>   


        </div>  


        ";
    }} 
    else {
        /*echo "<h1>Sorry dear!!</h1> "
        . "<h2>Your choice is not found in our seller buyer system.</h2></br>"
        . "<h3 style='color:blue'>So please try to type product category</h3></br>"
            ."<h4>If you want <b style='color:red'>Samsung brand</b> mobile then type</h4>"
            ."<h5 style='color:red'>mobile</h5>";*/
    }
    }} }}
    // if the serach_term not exist
    // show a message and clear inputs
   /* 
    
    
    mysqli_free_result($result);
    mysqli_close($con);
    
*/
    }}
    
function activate($email,$email_code)
{
    global $con;
    $email=  mysql_real_escape_string($email);
    $email_code=  mysql_real_escape_string($email_code);
    $query="select `username` from `customer` where `customer_email`='$email' and `email_code`='$email_code' and `active`=0 ";
   // if(mysql_result(mysql_query($query),0)===1){
    $run_query=  mysqli_query($con, $query);
    if(mysqli_num_rows($run_query)==1){
        $as="update `customer` set `active`=1 where `customer_email`='$email'";
        $run_as=  mysqli_query($con, $as);
        //return $run_as;
        return TRUE;
    }
 else {
        return FALSE;
        
    }
}
function message()
{
    
$message = "No message";
$msg = preg_replace('#[^a-z 0-9.:_()]#i', '', $_GET['msg']);
if($msg == "activation_failure"){
	$message = '<h2>Activation Error</h2> Sorry there seems to have been an issue activating your account at this time. We have already notified ourselves of this issue and we will contact you via email when we have identified the issue.';
} else if($msg == "activation_success"){
	$message = '<h2>Activation Success</h2> Your account is now activated. <a href="login.php">Click here to log in</a>';
} else {
	$message = $msg;
}
?>
<div><?php echo $message; ?></div>
<?php
}
?>
<?php 
function output_errors($errors)
{
    return '<u1><li>'.implode('</li></li>', $errors).'</l1></u1>';
} 
function email_exists($email){
    global $con;
    $username=sanitize($email);
    //$query1="select count(`username`) from `customer` where `username`='$username'";
    $query1="select `username` from `customer` where `username`='$username'";
    $run_quer1=  mysqli_query($con, $query1);
    if(mysqli_num_rows($run_quer1)===1)
    {
        return FALSE;
    }
    
    
//   return(mysql_result(mysql_query("select count(`username`) from `customer` where `username`='$username'"), 0)===1);
}
function sanitize($data)
{
    return mysql_real_escape_string($data);
}
 


function SendSMS ($host, $port, $username, $password, $phoneNoRecip, $msgText) { 

/* Parameters:
    $host - IP address or host name of the NowSMS server
    $port - "Port number for the web interface" of the NowSMS Server
    $username - "SMS Users" account on the NowSMS server
    $password - Password defined for the "SMS Users" account on the NowSMS Server
    $phoneNoRecip - One or more phone numbers (comma delimited) to receive the text message
    $msgText - Text of the message
*/
 
    $fp = fsockopen($host, $port, $errno, $errstr);
    if (!$fp) {
        echo "errno: $errno \n";
        echo "errstr: $errstr\n";
        return $result;
    }
    
    fwrite($fp, "GET /?Phone=" . rawurlencode($phoneNoRecip) . "&Text=" . rawurlencode($msgText) . " HTTP/1.0\n");
    if ($username != "") {
       $auth = $username . ":" . $password;
       $auth = base64_encode($auth);
       fwrite($fp, "Authorization: Basic " . $auth . "\n");
    }
    fwrite($fp, "\n");
  
    $res = "";
 
    while(!feof($fp)) {
        $res .= fread($fp,1);
    }
    fclose($fp);
    
 
    return $res;
}
?>
