<?php
include("includes/db.php");
if(isset($_GET['edit_product'])){
    $pro_id=$_GET['edit_product'];
    $get_pro="select * from products where product_id='$pro_id'";
    $run_pro=  mysqli_query($con, $get_pro);
    while ($row_pro =mysqli_fetch_array($run_pro))
    {
        $pro_id=$row_pro['product_id'];
        $pro_cat=$row_pro['product_cata'];
        $pro_brand=$row_pro['product_brand'];
        $pro_price=$row_pro['product_price'];
        $pro_title=$row_pro['product_title'];
        $pro_image=$row_pro['product_image'];
        $pro_keyword=$row_pro['product_keywords'];
        $pro_desc=$row_pro['product_desc'];
}
}
?>
<?php
include("includes/db.php");
?>
<!-- for text editor -->
<script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>
        <meta charset="UTF-8">
        <title>EDITION of product</title>
        <form action="" method="post" enctype="multipart/form-data">
        <table align="left" width="1000" height="500" border="6" bgcolor="whitesmoke">
            <tr align="center">
                <td colspan="8"><h2>EDIT YOUR PRODUCT</h2></td>
            </tr>
            <tr>
                <td align="right">Product Title</td>
                <td><input type="text" name="product_title"  size="70" value="<?php echo $pro_title;?>" required/></td>
            </tr>
            
             <tr>
                <td align="right">Product Category</td>
                <td>
                    <select name="product_cata">
                        <option>Categories</option>  
                        <?php
                  $get_cats="SELECT categories.cata_id,categories.cata_title,cloth_category.cloth_cata_title,cloth_category.cloth_cata_id FROM  categories , cloth_category where categories.cata_id=cloth_category.cloth_cata_id";
                       // $get_cats="select * from categories";   
                        $run_cats=mysqli_query($con,$get_cats);
                           while($row_cats=  mysqli_fetch_array($run_cats))
                           {
                               /* @var $cata_id type */
                               $cata_id=$row_cats['cata_id'];
                               $cata_cloth_id=$row_cats['cloth_cata_title'];
                               /* @var $cata_title type */
                              $cata_title=$row_cats['cloth_cata_title'] ;
                               $cata_CLOTH_title=$row_cats['cata_title'];
                              echo "<option value='$cata_id'>$cata_title</option>";
                              echo "<option value='$cata_cloth_id'>$cata_CLOTH_title</option>";
                           }
                        ?>
                    </select>
                </td>
            </tr>
            
             <tr>
                <td align="right">Product Brand</td>
                <td>
                    <select name="product_brand" >
                        <option>Brands</option>  
                        <?php
                           //$get_brands="SELECT * FROM  `brand`";
                           $get_brands="SELECT brand.brand_id,brand.brand_title,cloth_brand.cloth_brand_id,cloth_brand.cloth_brand_title FROM  brand , cloth_brand where (brand.brand_id=cloth_brand.cloth_brand_id)";

                            $run_brands=mysqli_query($con,$get_brands);
                            while($row_brands=  mysqli_fetch_array($run_brands))
                            {
                             
                                $brand_id=$row_brands['brand_id'];
                                $cloth_brand_id=$row_brands['cloth_brand_id'];
                                
                                $brand_title=$row_brands['brand_title'];
                                 
                                $cloth_brand_title=$row_brands['cloth_brand_title'];
                                echo "<option value='$brand_id'>$brand_title</option>";
                                echo "<option value='$cloth_brand_id'>$cloth_brand_title</option>";
                            }
                        ?>
                    </select>
                </td>
            </tr>
            
             <tr>
                <td align="right">Product Image</td>
                <td><input type="file" name="product_image" value="<?php echo $pro_image;?>">
                        
                 
                </td>
                    
                    
                    
                
            </tr>
            
             <tr>
                <td align="right">Product Price</td>
                <td><input type="text" name="product_price"  value="<?php echo $pro_price;?>"  /></td>
            </tr>
            
             <tr>
                <td align="right">Product Description</td>
               <td><textarea name="product_desc" rows="10" cols="20" value="<?php echo $pro_desc;?>"></textarea></td>
            </tr> 
            
            <tr>
                <td align="right" >Product Keywords</td>
                <td ><input type="text" name="product_keywords" size="70" value="<?php echo $pro_keyword;?>" /></td>
            </tr> 
            
            <tr>
                <td colspan="8" align="right"><input type="submit" name="insert_prdoduct" value="Upload" /></td>
            </tr>
            
            
            
            
        </table>
    </form>

<?php
if(isset($_POST['insert_prdoduct']))
{
$product_title=$_POST['product_title'];  
$product_cata=$_POST['product_cata'];
$product_brands = $_POST['product_brand']; 
$product_desc=$_POST['product_desc']; 
$product_keywords=$_POST['product_keywords']; 
$product_price=$_POST['product_price']; 
 
//image insertion ko lagi     
$product_image=$_FILES['product_image']['name'];
$product_image_tmp=$_FILES['product_image']['tmp_name'];


move_uploaded_file($product_image_tmp, "products_images/$product_image");

$insert_product="insert into products (product_cata,product_brand,product_price,product_desc,product_image,product_keywords,product_title) values ('$product_cata','$product_brands','$product_price','$product_desc','$product_image','$product_keywords','$product_title')";

$insert_prod=mysqli_query($con, $insert_product);
if($insert_prod)
{
    echo "<script>alert('product has been updated')</script>";
    echo "<script>window.open('index.php?view_product')</script>";
}
}
?> 