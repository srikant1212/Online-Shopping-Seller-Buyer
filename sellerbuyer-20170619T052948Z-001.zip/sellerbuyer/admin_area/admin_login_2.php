<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Admin Login form</title>
    <link rel="stylesheet" href="styles/style_login_2.css">
  
  </head>

  <body>

    
<div class="container">
	<section id="content">
            <form  action="" method="post">
			<h1>Admin Login Form</h1>
			<div>
				<input type="text" placeholder="Enter Username" required="" name="uname"  id="username" />
			</div>
			<div>
				<input type="password" placeholder="Enter Password" required="" name="pass" id="password" />
			</div>



			<div>
                            <input type="submit" name="submit" value="login"  />
                            <a href="admin_login_2.php?forgot_pass">Lost your password?</a>
                                <a href="admin_register.php">Register</a>


			</div>
		</form>
		
	</section>
</div>

    
        <script src="js/index.js"></script>
  </body>
</html>
       
<?php
include("includes/db.php");
        session_start();
global $con;

if (isset($_POST['submit'])){
    $password=  mysqli_escape_string($con, $_POST['pass']);
$username=$_POST['uname'];
$password=($_POST['pass']);
if (!$_POST['uname'] | !$_POST['pass'])
 {
echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('You did not complete all of the required fields')
        window.location.href='admin_login_2.php'
        </SCRIPT>");
exit();
     }
$sql= mysqli_query($con,"select * from admin where admin_uname='$username' and admin_password='$password'");
//$email="select `customer_email` from `customer` WHERE `username` = '$username' AND `password` = '$password' ";
if(mysqli_num_rows($sql) > 0)
{
    $_SESSION['admin_uname']=$username;
echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Login Succesfully!.')
        window.location.href='index.php'
        </SCRIPT>");
 





        
exit();
}
else{
    
echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Wrong username password combination.Please re-enter.')
        window.location.href='admin_login_2.php'
        </SCRIPT>");
exit();
}




}
else{
}
?>