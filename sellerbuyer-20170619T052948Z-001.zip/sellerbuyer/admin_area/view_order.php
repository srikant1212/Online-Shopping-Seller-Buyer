<table width="1000" align="center" bgcolor="whitesmoke">
    <tr>
        <td colspan="6"><h2>View all Buyer</h2></td>
    </tr>
    <tr>
        <th>S.N</th>
        <th>Name</th>
        <th>Date shipped</th>
         <th>Amount</th>
        
   
        <th>Delete</th>
    </tr>
    <?php
    include("includes/db.php");
    $get_cus="select * from order details";
    $run_cus=  mysqli_query($con, $get_cus);
    $i=0;
    while ($row_cus=  mysqli_fetch_array($run_cus)){
        $cus_id=$row_cus['orderId'];
        $cus_name=$row_cus['customerName'];
        $ds=$row_cus['dateShipped'];
        $payment=$row_cus['amount'];
        $dc=$row_cus['dateCreated'];
        
        $i++;
       
    
    
    
    ?>
    <tr align="center">
        <td><?php echo $i;?></td>
        <td><?php echo $cus_name;?></td>
        <td><?php echo $ds;?></td>
        <td><?php echo $payment;?></td>
        
        
       
        <td><a href="delete_order.php?delete_order=<?php echo $cus_id; ?>">Delete</a></td>
    </tr>
    <?php } ?>
    
    
</table>