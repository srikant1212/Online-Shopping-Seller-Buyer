<?php
include("includes/db.php");
if(isset($_GET['edit_cat'])){
    $cat_id=$_GET['edit_cat'];
    $get_cat="select * from categories where cata_id='$cat_id'";
    $run_cat=  mysqli_query($con, $get_cat);
    $row_cat=  mysqli_fetch_array($run_cat);
    $cat_title=$row_cat['cata_title'];
    $cat_id=$row_cat['cata_id'];
}


?>
<form action="" method="post" style="padding: 100px">
    <b>Update category</b>
    <input type="text" name="new_category" value="<?php echo $cat_title;?>"/>
    <input type="submit" name="add_category" value="Update Category"/>
</form>
<?php
 
if(isset($_POST['add_category'])){
    $new_cat=$_POST['new_category'];
    $insert_cat="insert into categories (cata_title) values('$new_cat')";
    $run_cat=  mysqli_query($con, $insert_cat);
    if($run_cat){
        echo "<script>alert('category has been edited')</script>";
        echo "<script>window.open('index.php?view_cats','_self')</script>";
    }
}
?>
