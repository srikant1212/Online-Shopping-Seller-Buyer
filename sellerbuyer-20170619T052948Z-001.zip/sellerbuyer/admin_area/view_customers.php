<table width="1000" align="center" bgcolor="whitesmoke">
    <tr>
        <td colspan="6"><h2>View all Customers</h2></td>
    </tr>
    <tr>
        <th>S.N</th>
        <th>Name</th>
        <th>Email</th>
        
   
        <th>Delete</th>
    </tr>
    <?php
    include("includes/db.php");
    $get_cus="select * from customer";
    $run_cus=  mysqli_query($con, $get_cus);
    $i=0;
    while ($row_cus=  mysqli_fetch_array($run_cus)){
        $cus_id=$row_cus['customer_id'];
        $cus_name=$row_cus['username'];
        $cus_email=$row_cus['customer_email'];
        
        $i++;
       
    
    
    
    ?>
    <tr align="center">
        <td><?php echo $i;?></td>
        <td><?php echo $cus_name;?></td>
        <td><?php echo $cus_email;?></td>
        
       
        <td><a href="delete_customer.php?delete_customer=<?php echo $cus_id; ?>">Delete</a></td>
    </tr>
    <?php } ?>
    
    
</table>