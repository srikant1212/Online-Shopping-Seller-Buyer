<?php
session_start();
session_destroy();
echo "<script>window.open('admin_login_2.php','_self')</script>";
?>
