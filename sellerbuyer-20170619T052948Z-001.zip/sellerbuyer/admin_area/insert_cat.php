<form action="" method="post" style="padding: 100px">
    <b>Insert a new category</b>
    <input type="text" name="new_category" required/>
    <input type="submit" name="add_category" value="Add Category"/>
</form>
<?php
 include("includes/db.php");
if(isset($_POST['add_category'])){
    $new_cat=$_POST['new_category'];
    $insert_cat="insert into categories (cata_title) values('$new_cat')";
    $run_cat=  mysqli_query($con, $insert_cat);
    if($run_cat){
        echo "<script>alert('New category has been inserted')</script>";
        echo "<script>window.open('index.php?view_cats','_self')</script>";
    }
}
?>
