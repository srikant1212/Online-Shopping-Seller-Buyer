<?php
include("includes/db.php");
if(isset($_GET['delete_order'])){
    $delete_id=$_GET['delete_order'];
    $delete_customer="delete from order details where customer_id='$delete_id'";
    $run_delete=  mysqli_query($con, $delete_customer);
    if($run_delete){
        echo "<script>alert('A order has been deleted')</script>";
        echo "<script>window.open('index.php?view_order','_self')</script>";
    }
}
?>

