<?php
include("includes/db.php");
if(isset($_GET['delete_buyer'])){
    $delete_id=$_GET['delete_buyer'];
    $delete_customer="delete from buyer where customer_id='$delete_id'";
    $run_delete=  mysqli_query($con, $delete_customer);
    if($run_delete){
        echo "<script>alert('A buyer_customer has been deleted')</script>";
        echo "<script>window.open('index.php?view_buyer','_self')</script>";
    }
}
?>

