<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Admin Login Form</title>
    
    
    
    <link rel='stylesheet prefetch' href='http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css'>

    <link rel="stylesheet" href="styles/styles_login.css">
  </head>

   <body>

    <link href='http://fonts.googleapis.com/css?family=Ubuntu:500' rel='stylesheet' type='text/css'>

<div class="login">
  <div class="login-header">
    <h1>Admin Login</h1>
  </div>
  <div class="login-form">
    <h3>Username:</h3>
    <input type="text" placeholder="Username" name="username"/><br>
    <h3>Password:</h3>
    <input type="password" placeholder="Password" name="password"/>
    <br>
    <input type="button" value="Login" name="submit" class="login-button"/>
    
    
  </div>
</div>
    

<?php
        
        include("includes/db.php");
        session_start();
      if(isset($_POST['submit'])){
    
    
            $uname= mysql_real_escape_string($_POST['username']);
    
            $pass=  mysql_real_escape_string($_POST['password']);
    
    
            $sel_user="select * from admin where admin_uname='$uname' and admin_password='$pass'";
    
            $run_user=  mysqli_query($con, $sel_user);
    
            $check_user=  mysqli_num_rows($run_user);
    
            if($check_user==0)
    
                {
        
                echo "<script>alert('Wrong username and password!!!!!')</script>";
        
    
                
                }
 
                else
     
                    {
     
                    $_SESSION['admin_uname']=$uname;
     
                    echo "<script>window.open('index.php?Logged In=Succesfully Logged In','_self')</script>";
                    }
    }
 ?>
<div class="error-page">
  <div class="try-again">Error: Try again?</div>
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js'></script>

        <script src="js/index.js"></script>

    
    
    
  </body>
</html>
