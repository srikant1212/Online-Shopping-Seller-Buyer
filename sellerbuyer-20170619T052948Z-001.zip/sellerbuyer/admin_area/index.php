<?php
session_start();
if(!isset($_SESSION['admin_uname'])){
    echo "<script>window.open('admin_login_2.php','_self')</script>";
}
 else {
    
 
?>
<!DOCTYPE>
<html>
    <head>
        <title>THIS IS ADMIN AREA</title>
        <link rel="stylesheet" href="styles/styles.css" media="all">
    </head>
    <body>
        <div class="main_wrapper">
            
            <div id="header"><h2 style="text-align: center ; colol:black;"><b>ADMIN AREA</b></h2>
                <h2 style="margin-left: 480px;">Manage your product information</h2></div>
            
            <div id="right">
                <div id="right">
                    
                   
                <?php
                if(isset($_GET['insert_product']))
                    {
                    include ("insert_product.php");
                    }
                if(isset($_GET['insert_cloth']))
                    {
                    include ("insert_cloth.php");
                    }
                if(isset($_GET['view_products']))
                    {
                    include ("view_products.php");
                    }
                if(isset($_GET['insert_cat']))
                    {
                    include ("insert_cat.php");
                    }    
                    
                if(isset($_GET['view_cats']))
                    {
                    include ("view_cats.php");
                    }
                if(isset($_GET['insert_brand']))
                    {
                    include ("insert_brand.php");
                    } 
                if(isset($_GET['view_brands']))
                    {
                    include ("view_brand.php");
                    }
                if(isset($_GET['view_customers']))
                    {
                    include ("view_customers.php");
                    }
                if(isset($_GET['edit_cat']))
                    {
                    include ("edit_cat.php");
                    }
                if(isset($_GET['edit_brand']))
                    {
                    include ("edit_brand.php");
                    }
                if(isset($_GET['admin_logout']))
                    {
                    include ("admin_logout.php");
                    }
                     if(isset($_GET['view_payment']))
                    {
                    include ("view_buyer.php");
                    }
                     if(isset($_GET['view_order']))
                    {
                    include ("view_order.php");
                    }
                if(isset($_GET)==TRUE) {
                    ?> 
                    <img style="margin-top: 0px;" src="images/web.jpg" width="1000px" height="400px">
                    <?php
                   }
                ?> 
                 
                    
            </div>
            </div>
            <div id="left">
                <h2 style="text-align: center; color: highlight;"><b>Manage Content</b></h2>
                <a href="index.php?insert_product">Insert Electronics Product</a>
                <a href="index.php?insert_cloth">Insert Cloths Product</a>
                <a href="index.php?view_products">View all Products</a>
                <a href="index.php?insert_cat">Insert New Categories</a>
                <a href="index.php?view_cats">View all Categories</a>
                <a href="index.php?insert_brand">Insert New Brand</a>
                <a href="index.php?view_brands">View all Brands</a>
                <a href="index.php?view_customers">View Customers</a>
                <a href="index.php?view_order">View Orders</a>
                <a href="index.php?view_payment">View Payment</a>
                <a href="admin_logout.php?admin_logout">Admin Logout</a>
            </div>
            
            
        </div>
        
        
        
        
    </body>
</html>
 <?php } ?>