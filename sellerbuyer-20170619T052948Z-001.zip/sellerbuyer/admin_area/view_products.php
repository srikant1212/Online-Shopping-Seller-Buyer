<table width="1000" align="center" bgcolor="whitesmoke">
    <tr>
        <td colspan="6"><h2 align="center">View all Categories</h2></td>
    </tr>
    <tr>
        <th>Product ID</th>
        <th>Product Title</th>
        <th>Edit</th>
        <th>Delete</th>
    </tr>
    <?php
    include("includes/db.php");
    $get_pro="select * from products";
    $run_pro=  mysqli_query($con, $get_pro);
    $i=0;
    while ($row_pro =mysqli_fetch_array($run_pro))
    {
        $pro_id=$row_pro['product_id'];
        $pro_cat=$row_pro['product_cata'];
        $pro_brand=$row_pro['product_brand'];
        $pro_price=$row_pro['product_price'];
        $pro_title=$row_pro['product_title'];
        $pro_image=$row_pro['product_image'];
        $i++;
    ?>
    <tr align="center">
        <td><?php echo $pro_id;?></td>
        <td><?php echo $pro_title;?></td>
        <td><a href="edit_product.php?edit_product=<?php echo $pro_id;?>">Edit</a></td>
        <td><a href="delete_product.php?delete_pro=<?php echo $pro_id;?>">Delete</a></td>
    </tr>
    <?php } ?>
    
    
</table>