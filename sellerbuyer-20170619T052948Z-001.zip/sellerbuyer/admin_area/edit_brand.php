<?php
include("includes/db.php");
if(isset($_GET['edit_brand'])){
    $brand_id=$_GET['edit_brand'];
    $get_brand="select * from brand where brand_id='$brand_id'";
    $run_brand=  mysqli_query($con, $get_brand);
    $row_brand=  mysqli_fetch_array($run_brand);
    $brand_title=$row_brand['brand_title'];
    $brand_id=$row_brand['brand_id'];
}


?>
<form action="" method="post" style="padding: 100px">
    <b>Insert a new Brand</b>
    <input type="text" name="new_brand" value="<?php echo $brand_title;?>"/>
    <input type="submit" name="add_brand" value="Update Brand"/>
</form>
<?php
 include("includes/db.php");
if(isset($_POST['add_brand'])){
    $new_brand=$_POST['new_brand'];
    $insert_brand="insert into brand (brand_title) values('$new_brand')";
    $run_brand=  mysqli_query($con, $insert_brand);
    if($run_brand){
        echo "<script>alert('Brand has been Updated')</script>";
        echo "<script>window.open('index.php?view_brands','_self')</script>";
    }
}
?>
