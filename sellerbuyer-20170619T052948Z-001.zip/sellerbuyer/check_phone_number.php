<?php
if(isset($_POST["phone2check"]) && $_POST["phone2check"] != ""){
    include_once 'includes/db.php';
    $phone1 = preg_replace('#[a-z]#i','', $_POST['phone2check']); 
     $phone = preg_replace('#[^0-9]#i','', $_POST['phone2check']); 
    //$sql_uname_check = mysql_query("SELECT customer_id FROM customer WHERE username='$username' LIMIT 1"); 
    $sql_phone_check = "SELECT customer_id FROM customer WHERE phone='$phone' LIMIT 1";
	$run_sql=mysqli_query($con,$sql_phone_check);
	$phone_check = mysqli_num_rows($run_sql);
        $count_num=strlen($phone) ;
        //if(strlen($phone1)<15)
        //{
          //echo ' Integer number please';
     //exit();   
       // }
    if ($count_num== 10)  {
         if ($phone_check < 1) {
	   
                if($phone[0]=='9' && $phone[1]=='8')
                {
                     echo '<strong>' . $phone . '</strong> is OK';
	             exit();
                }
                else
                {
                      echo 'Enter phone number starting with 98..';
	              exit(); 
                }
            }
            else {
	    echo '<strong>' . $phone . '</strong> is taken';
	    exit();
    }
    }
 else {
     echo '10 characters please';
     exit();
 }
        
    
    
    
    
}
?>
<html>
<head>
<script>
function checkphone(){
	var status = document.getElementById("phonestatus");
	var u = document.getElementById("ph").value;
	if(u != ""){
		status.innerHTML = 'checking...';
		var hr = new XMLHttpRequest();
		hr.open("POST", "check_phone_number.php", true);
		hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		hr.onreadystatechange = function() {
			if(hr.readyState == 4 && hr.status == 200) {
				status.innerHTML = hr.responseText;
			}
		}
        var v = "phone2check="+u;
        hr.send(v);
	}
}
</script>
</head>
<body>
<input type="number" name="phone" id="ph" onBlur="checkphone()" maxlength="10">
 <!-- <input type="number" name="phone" class="form-control" placeholder="Phone number" value=""><br />-->
<span id="phonestatus"></span>
</body>
</html>