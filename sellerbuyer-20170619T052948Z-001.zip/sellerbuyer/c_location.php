<?php
include("functions/functions.php");
include("includes/db.php");
global  $con;
$user_ip = getenv('REMOTE_ADDR');
//$user_ip=  getIp();
$geo = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip='$user_ip'"));
$city = $geo["geoplugin_city"];
$region = $geo["geoplugin_regionName"];
$country = $geo["geoplugin_countryName"];
echo "City: ".$city."<br>";
echo "Region: ".$region."<br>";
echo "Country: ".$country."<br>";
$insert_query="INSERT INTO customer(city,region,country ) VALUES ('$city','$region','$country')";	
$run_query=  mysqli_query($con, $insert_query); 
/*
geoplugin_request
geoplugin_status
geoplugin_credit
geoplugin_city
geoplugin_region
geoplugin_areaCode
geoplugin_dmaCode
geoplugin_countryCode
geoplugin_countryName
geoplugin_continentCode
geoplugin_latitude
geoplugin_longitude
geoplugin_regionCode
geoplugin_regionName
geoplugin_currencyCode
geoplugin_currencySymbol
geoplugin_currencySymbol_UTF8
geoplugin_currencyConverter
*/
?>