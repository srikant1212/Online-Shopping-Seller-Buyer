<?php
if(isset($_POST["name3check"]) && $_POST["name3check"] != ""){
    include_once 'includes/db.php';
    $email = preg_replace('[^a-z0-9]', '', $_POST['name3check']); 
    //$sql_uname_check = mysql_query("SELECT customer_id FROM customer WHERE username='$username' LIMIT 1"); 
    $sql_email_check = "SELECT customer_id FROM customer WHERE customer_email='$email' LIMIT 1";
	$run_sql=mysqli_query($con,$sql_email_check);
	$email_check = mysqli_num_rows($run_sql);
    if (strlen($email) < 4) {
	    echo '4 - 20 characters please';
	    exit();
    }
	if (is_numeric($email[0])) {
	    echo 'First character must be a letter';
	    exit();
    }
    if ($email_check < 1) {
	    echo '<strong>' . $email. '</strong> is OK';
	    exit();
    } else {
	    echo '<strong>' . $email. '</strong> is taken';
	    exit();
    }
}
?>
<html>
<head>
<script>
function checkemail(){
	var status = document.getElementById("emailstatus");
	var u = document.getElementById("email_id").value;
	if(u != ""){
		status.innerHTML = 'checking...';
		var hr = new XMLHttpRequest();
		hr.open("POST", "check_email.php", true);
		hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		hr.onreadystatechange = function() {
			if(hr.readyState == 4 && hr.status == 200) {
				status.innerHTML = hr.responseText;
			}
		}
        var v = "name3check="+u;
        hr.send(v);
	}
}
</script>
</head>
<body>
<input type="email" name="email" id="email_id" onBlur="checkemail()" maxlength="30">
<span id="emailstatus"></span>
</body>
</html>