<?php
include('includes/db.php');
//include('functions/functions.php');
  $total=0;
    global $con;
    function getkIp() {
    $ip = $_SERVER['REMOTE_ADDR'];
 
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
 
    return $ip;
}
   $ip=  getkIp();
   $sel_price= "select * from cart where ip_address='$ip'";
    $email=$_SESSION['customer_emailll'];
   // $sel_price= "select * from cart where customer_email='$email'";
    $run_price= mysqli_query($con, $sel_price);
    while($p_price=  mysqli_fetch_array($run_price)){ 
        $pro_id=$p_price['p_id'];
        if($pro_id < 10){
        $pro_price="select * from products where product_id='$pro_id'";}
        else {
        $pro_price="select * from clothproducts where product_id='$pro_id'";}
        $run_pro_price=  mysqli_query($con, $pro_price);
        while ($pp_price=  mysqli_fetch_array($run_pro_price)){
            $product_price=array($pp_price['product_price']);
            $product_name=$pp_price['product_title'];
            $values=  array_sum($product_price);
            $total=$total+$values;
            
        }
         
    }
?>
<div>
    <h2 style="margin-right:150px">Pay with E-sewa or Paypal</h2>
<div>
    <form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">
        <!--bisiness name and email-->
   <input type="hidden" name="business" value="srikant_business@gmail.com">
 
   <!--specifying buy now button-->
  <input type="hidden" name="cmd" value="_s-xclick">
 <!--  <input type="hidden" name="cmd" value="_xclick">-->
 
  <!-- //specifying products information -->
  <input type="hidden" name="hosted_button_id" value="6RNT8A4HBBJRE">
   <input type="hidden" name="item_name" value="<?php echo $product_name; ?>">
   <input type="hidden" name="amount" value="<?php echo $total; ?>">
   <input type="hidden" name="currency_code" value="NPR">
   
    <input type="hidden" name="return" value="http://www.sellerbuyer.com/shop/paypal_sucess.php">
    <input type="hidden" name="cancel_return" value="http://www.sellerbuyer.com/shop/paypal_cancel.php">
  
  
  
  <input style="margin-right: 150"type="image"
    src="images/paypal2.png" width="290" height="80"
    name="submit" alt="PayPal - The safer, easier way to pay online!">
  <img alt="" src="https://www.sandbox.paypal.com/en_US/i/scr/pixel.gif"
    width="1" height="1">
  
</form>
    <form action="esewa.php">
       
     <input style="margin-right: 150"type="image"
            src="images/esewa.png" width="290" height="80">
   
    </form>
    
    
    
    
    
    
    <form action="cash_on_delivery.php">
       
     <input style="margin-right: 150"type="image"
            src="cash_on_delivery.png" width="290" height="80">
    </form>
</div>  
</div>
