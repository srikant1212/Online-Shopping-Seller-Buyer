<!DOCTYPE>
<html>
    <head>
        <title>PASSWORD FORGOT</title>
        <link rel="stylesheet" href="styles/styles.css" media="all"/>
    </head>
    <style>
input[type=email], select {
    width: 50%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=password], select {
    width: 50%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
input[type=submit] {
    width: 50%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

div {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>
    <body>
        
        
        
        
        <?php
include("functions/functions.php");
if(isset($_GET['change']) ===TRUE && empty($_GET['change'])===true){
    ?>
<h2><b>Thanks, Now you will able to change your password.</b></h2>
<h3>please put your new password for <b style="color: blue">Seller Buyer System</b></h3>
<?php
 echo "<a href='index.php' style='color:red;'>HOME</a>"; ?>
<?php
    
}
elseif (isset($_GET['email']) && isset($_GET['email_code'])==TRUE) {
   
    $email=  trim($_GET['email']);
    $email_code=  trim($_GET['email_code']);

   



    if(email_exists($email)===FALSE)
    {
        $errors[]='Oops, something went wrong, we could not find your email address';
    }
    
    if(empty($errors)===FALSE){
        ?>
<h2>Oops........</h2>
<?php
echo output_errors($errors);
    }
    else{
        header('Location:new_password.php?change');
      

        exit();
    }
    

}



 else {
    
header('Location:index.php');
exit();
 }
 ?>

        <form align="center"  action="" method="post">
            
			
            <!--Email:    <input type="email" name="email" placeholder="Email Again" value=""></br>
            New Password:    <input type="password" name="pass" placeholder="New password" value=""></br>
            Conform Password:<input type="password" name="cpass" placeholder="New password" value=""></br>
            <input type="submit" name="conform" value="Conform">-->
           
    <div>
   
      <input type="email" name="email" placeholder="Email Again" value="" id="email">

   
    <input type="password" name="pass" placeholder="New password" value="">
     
      <input type="password" name="cpass" placeholder="Conform password" value="">
      <input type="submit" name="conform" value="Conform">
    </div>
  </form>

      
    </body>
</html>
<?php
//global $con;
   if(isset($_POST['conform'])){
        if($_POST['pass']==$_POST['cpass']){
            if($_GET['email']=$_POST['email']){
      
       
        $pass=$_POST['pass'];
        $email=$_POST['email'];
        $insert_pass="UPDATE  `customer` SET  `password` =  '$pass' WHERE  `customer_email` =  '$email'";

        $run_insert_pass= mysqli_query($con,$insert_pass);
        }
      
      {?>
          <?php
          
          echo "<script>alert('Others Email !! Please enter your activated email address')</script>";
      }
        }
    else{
       
         echo "<script>alert('passwords do not match.')</script>";
       }
}  else {
echo "You are not submited your new password yet!!!!";    
}
?>