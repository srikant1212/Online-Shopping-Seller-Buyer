<?php
$to = "+9779803509958@sms.ncell.com.np,+9779811078948@sms.ncell.com.np,+9779811935541@sms.ncell.com.np";//+818043759804@softbank.ne.jp";
$from = "shrikantkandel@gmail.com";
$message = "Hi\nThis is Srikant kandel...either reply me on viber or direct call on my cell phone...";
$headers = "From: $from\n";
if(mail($to, '', $message, $headers))
{
    echo "Success!!";
}
 else {
    
echo "Fail!!";
     
 }

?>