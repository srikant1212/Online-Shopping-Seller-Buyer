<!DOCTYPE>
<?php
session_start();
include("functions/functions.php");
?>

<html>
    <head>
        
        <meta charset="UTF-8">
        <title>Seller Buyer</title>
        
        <link rel="stylesheet" href="styles/styles.css" media="all"/>
        
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
<link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>   
   
<!-- for top down menu-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>



    </head>
    <body>
        
        <!-- sab vanda mathi ko navigation -->
         <nav class="navbar navbar-inverse navbar-fixed-top">
      
        <div class="navbar-header">
            <a class="navbar-brand" href="index.php">Seller Buyer Nepal Online shopping </a>
        </div>
        
             <form class="navbar-form navbar-right" method="post">
                  <?php
         //  if(!isset($_POST['submit']))
             if(!isset($_SESSION['customer_emailll']))
           {
           ?>
            <div class="form-group">
                <input type="text" placeholder="Enter Username" name="uname" class="form-control">
            </div>
            <div class="form-group">
                <input type="password" placeholder="Password"  name="pass" class="form-control">
            </div>
            
     
        <!-- <button  type="submit" class="btn btn-success"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>
             <a href='checkout.php' style='color:white;'>Log In</a>
            </button>-->
          
             <button  type="submit" class="btn btn-success" name="submit"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>
             Log In
            </button>
             
           <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>
             <a href="customer_register.php"  style='color:white;'>Sign Up</a>
            </button>
           <?php } ?>
             <?php
             global $con;
require ('db.php');
if (isset($_POST['submit'])){
$password=  mysqli_escape_string($con, $_POST['pass']);
$username=$_POST['uname'];
$password=md5($_POST['pass']);
if (!$_POST['uname'] | !$_POST['pass'])
 {
echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('You did not complete all of the required fields')
        window.location.href='checkout.php'
        </SCRIPT>");
exit();
     }

$sql= mysqli_query($con,"SELECT * FROM `customer` WHERE `username` = '$username' AND `password` = '$password' AND `active`=1");
$email="select * from `customer` WHERE `username` = '$username' AND `password` = '$password' AND `active`=1 "; 
$run_email=  mysqli_query($con, $email); 

 
if(mysqli_num_rows($sql) > 0)
{
    $_SESSION['customer_emailll']=$email;
    echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Login Succesfully!.')
        window.location.href='index.php'
        </SCRIPT>");
    
    
   /* $select_emaill="select email from logged_user where active =1";
    $run_select_emaill=  mysqli_query($con, $select_emaill);
    
if(mysqli_num_rows($run_select_emaill) ==0){    
$insert_query="INSERT INTO logged_user(firstname,lastname,customer_email,email_code,address,phone,username,password,customer_ip ) VALUES ('$firstname','$lastname','$email','$email_code','$address','$phone','$username','$password','$ip')";	
$run_query=  mysqli_query($con, $insert_query); 
} */   
exit();
}
else{
    
echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Either Wrong info or Not email activation.Please re-enter.')
        window.location.href='checkout.php'
        </SCRIPT>");
exit();
}
}
else{
}
                          
             
                 

               //if(isset($_GET['success']) ===TRUE && empty($_GET['success'])===TRUE)
               // if(isset($_GET['activated'])===TRUE)
                

                 if(isset($_SESSION['customer_emailll']))
                       {
                     
                        // echo "<b>Hi, " .$email . "  You are logged in</b>";
                     echo "<b>".$_SESSION['customer_email']."</b>";
                      
                        
                       }
                       
                  
              ?>
                
                   <?php
                        if(!isset($_SESSION['customer_emailll']))
                        {
                           echo "<a href='checkout.php' style='color:red ; text-align:left ;'></a>";
                          
                        }
                        else
                        {
                           
                          // echo "<b>Hi,</b>".$_SESSION['customer_emailll']; 
                             ?>
                 <a class="btn btn-danger" href="logout.php" role="button"><span class="glyphicon glyphicon-off"></span></a>
                  
                            <?php
                        }
                        ?>
                
             </form>
                       
          
       <!--/.navbar-collapse -->
      
    </nav>
       <!-- sab vanda mathi ko navigation -->  
        
        
        
        <div class="main_wrapper" >
            
            <div class="header_wrapper" > 
               <!-- <img id ="logo" src ="images/logo.gif"/>-->
                <img id="banner" src="images/banner.gif" />
                
            </div>
            
           
            <div class="menubar">
                
                <ul id="menu">
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="all_products.php">ALL PRODUCT</a></li>
                    <li><a href="cart.php">SHOPPING CART</a></li>
                    <li><a href="customer/my_account.php">MY ACCOUNT</a></li>
                    <style>
.dropbtn {
    background-color: black;
    color: white;
    padding: auto;
    font-size: 18px;
    border: none;
    cursor: pointer;
    font-family: 'Oswald', sans-serif;
}

.dropdown {
    position: relative;
    display: inline-block;
   
   
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: black;
    min-width: 300px;
    font-family: 'Oswald', sans-serif;
      font-size: 18px;
    
   
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: lightskyblue}

.dropdown:hover .dropdown-content {
    box-sizing: border-box;

    display: table-column;
}

.dropdown:hover .dropbtn {
    background-color:lightskyblue;
}
</style>

<div class="dropdown">
    <button class="dropbtn"><a href="customer/my_account.php">ACCOUNT SETTING</a></button>
  <div class="dropdown-content">
                        <a href="customer/customer_info_change.php?change_my_info">EDIT MY INFO</a>
                        <a href="forgot_pass.php?">CHANGE PASSWORD</a>
                        <a href="my_account.php?delete">DELETE ACCOUNT</a>
                        <a href="my_account.php?logout">SHOPPING CART</a>
                        
                       
                        
                       
                           
                        
                       
                        
  </div>
</div>

                    <li><a href="contact_us.php">CONTACT US</a></li>
                </ul>
               
                <!--
                <div id="form">
                    <form method="get" action="results.php" enctype="multipart/formdata">
                        <input type="text" name="user_query" placeholder="Search a product"/>
                        <input type="submit" name="search" value="search"/>
                    </form>
                </div>
                    
                -->
            
             
 <!--            
<ul class="nav nav-tabs">
    
                    <li><a href="#">HOME</a></li>
                    <li><a href="#">ALL PRODUCT</a></li>
                    <li><a href="#">SHOPPING CART</a></li>
  <li role="presentation" class="dropdown">
    <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
      Sign Up <span class="caret"></span>
    </a>
    <ul class="dropdown-menu">
    <li><a href="#">Action</a></li>
    <li><a href="#">Another action</a></li>
    <li><a href="#">Something else here</a></li>
      <li><a href="#">MY ACCOUNT</a></li> 
    </ul>
  </li>
       <li><a href="#">CONTACT US</a></li>-->
 

            
             
             
             
 <!--<form class="navbar-form navbar-right" action="results.php" role="search" method="post">
  <div class="form-group">
      
      <input type="search" class="form-control" placeholder="Search a product" results="5" value="">
  </div>
    <button type="submit" class="btn btn-default" value="search" name="s"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
</form> -->
 
 <form class="navbar-form navbar-right" action="results.php" method="post">
 <?php global $search_term;
         if(isset($_POST['s'])){
   
    $search_term = $_POST['s'];
         } ?>
       
    
     <input type="search"  class="form-control" placeholder="Search a product" name="s" results="5" value="<?php echo $search_term;?>">

        
        <input class="btn btn-default"  type="submit" name="search" value="Search">

           </form>
      
           
             
     </div>         
            
            <!--<div class="content_wrapper">-->
                <div id="content_area">       
                  <?php cart(); 
                   cart_for_details();
               cart_for_details_cloth() ;?>
                <div id="shopping_cart">
                    <span style="float: right"> <b style="color: greenyellow">Shopping cart</b>
                        Total Items:<b style="color: blue"><?php total_items();?></b> Total Price:<b style="color: blue">Rs.<?php total_price();?></b> 
                        <a href="cart.php">Go to Cart</a>
                        
                        
                    
                    </span>
                    
                </div>
                   
                    
                    <div id="products_box">
                        <?php  getproduct(); ?> 
                       <?php // get_search_result();?>
                       
                        <?php  getcatproduct(); ?>
                        <?php getbrandproduct();?>
                         <?php get_cloth_brand_product();?>
                        <?php get_cloth_cata_product();?>
                        
                        
                    </div>
                        
                
                </div>

                <div id="sidebar">
                    <div id="sidebar_title">Clothing Category</div>
                    <ul id="products">
                        <?php
                        //getWoman_Fashion();
                        getclothcata();
                        ?>
                   </ul>
                    <div id="sidebar_title">Clothing Brand</div>
                    <ul id="products">
                        <?php
                       // getMen_Fashion();
                        getclothbrand();
                        ?>
                   </ul>
                   
                  <!--static 
                  <div id="sidebar_title">Mobiles and Tablets</div>
                    <ul id="products">
                        <li><a href="#">Macbooks</a></li>
                        <li><a href="#">Ultraboks</a></li>
                        <li><a href="#">Android</a></li>
                        <li><a href="#">Dell</a></li>
                        <li><a href="#">HP</a></li>
                        <li><a href="#">Acer</a></li>     
                   </ul>
                  !-->
                      <div id="sidebar_title">Electronics Categories</div>
                    <ul id="products">
                       <?php
                       getCats();
                       ?> 
                   </ul>
                    <div id="sidebar_title">Electronics Brands</div>
                    <ul id="products">
                       <?php
                       getBrands();
                       ?> 
                   </ul>
               
               
                
            </div>
            </div>
                
                
            
            
           
               <div class="footer">
                <ul id="footerr">
                
                    <li><a href="about_us.php">About Us</a></li>
                    <li><a href="conditions.php">Terms and Conditions</a></li>
                    <li><a href="contact_us.php">Contact Us</a></li>
                    <li><a href="support.php">Support</a></li>
                    
                </ul>
            </div><!-- 
              </div>
              <div class="well well-lg">
                <!--  <ul id="footerr">
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Terms and Conditions</a></li>
                    <li><a href="#">Support</a></li>  
                  </ul>
             
                    <address>
                    <strong style="text-align:center">About Me</strong><br>
                     Imadol-09<br>
                     Kathmandu, Nepal<br>
                     <abbr title="Phone">Mb no.:</abbr> 981193500
                    <a href="mailto:#">srikant_kandel@yahoo.com</a>
                    </address>  -->
              
                            
      
        <!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    </body>
</html>
