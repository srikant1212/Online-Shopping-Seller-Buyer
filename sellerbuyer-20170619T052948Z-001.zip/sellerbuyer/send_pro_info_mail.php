<?php
include 'functions/functions.php';
 $total=0;
                                        global $con;
                                        $ip=  getIp();
                                        $sel_price= "select * from cart where ip_address='$ip'";
                                        $run_price= mysqli_query($con, $sel_price);
                                        while($p_price=  mysqli_fetch_array($run_price)){ 
                                            $pro_id=$p_price['p_id'];
                                            $pro_price="select * from products where product_id='$pro_id'";
                                            $run_pro_price=  mysqli_query($con, $pro_price);
                                            while ($pp_price=  mysqli_fetch_array($run_pro_price)){
                                                $product_price=array($pp_price['product_price']);  
                                                $product_title=$pp_price['product_title'];
                                                $product_image=$pp_price['product_image'];
                                                $single_price=$pp_price['product_price'];
                                                $values=  array_sum($product_price);
                                            $total=$total+$values;
                                            
                                            }
                                        }
                                

$to    = 'srikantkandel@gmail.com';
$subject = 'Your products';
$message = " 
    <!DOCTYPE>
    <html>
    <head>
        <title>Products Info</title>
        
        
    </head>
    <body>
        <div>
<p>This email contains products information!</p>
<table>
<tr>
<th>Product Name</th>
<th>Product Price</th>
<th>Total_Price</th>
</tr>
 
<tr>
<td>$product_title </td>
    <td>$total</td>
   
<td>$total</td>
</tr>
</table>           
</div> 
</body>
</html>" ;

$headers = 'From: shrikantkandel@gmail.com' . "\r\n" .
           'Reply-To: shrikantkandel@gmail.com' . "\r\n" .
           'Content-type: text/html; charset=utf-8' . "\r\n".
           'X-Mailer: PHP/' . phpversion();
         

if(mail($to, $subject, $message, $headers)) {
    echo 'check your email to get your billing as well as product information';
    echo '<button><a href="index.php">Home</a></button>';
} 
                                        
else {
    die('Failure: Email was not sent!');
} 

?>
                                            