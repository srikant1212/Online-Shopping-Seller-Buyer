-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2016 at 09:29 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sellerbuyer_2`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_uname` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_uname`, `admin_password`) VALUES
('b', 'b');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE IF NOT EXISTS `brand` (
  `brand_id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_title` varchar(255) NOT NULL,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brand_id`, `brand_title`) VALUES
(1, 'HP'),
(2, 'Sony'),
(3, 'Dell'),
(4, 'Samsung'),
(5, 'ACER'),
(6, 'WINDOWS'),
(7, 'FAD');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`p_id`, `ip_address`, `qty`) VALUES
(8, '::1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `cata_id` int(11) NOT NULL AUTO_INCREMENT,
  `cata_title` varchar(255) NOT NULL,
  PRIMARY KEY (`cata_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cata_id`, `cata_title`) VALUES
(1, 'TV'),
(2, 'Laptop'),
(3, 'Mobile'),
(4, 'Camera');

-- --------------------------------------------------------

--
-- Table structure for table `clothproducts`
--

CREATE TABLE IF NOT EXISTS `clothproducts` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_title` varchar(255) NOT NULL,
  `product_cata` int(11) NOT NULL,
  `product_brand` int(11) NOT NULL,
  `product_desc` text NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` varchar(255) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `clothproducts`
--

INSERT INTO `clothproducts` (`product_id`, `product_title`, `product_cata`, `product_brand`, `product_desc`, `product_price`, `product_image`, `product_keywords`) VALUES
(11, 'Pant', 1, 1, '<p>Pant....Nike</p>', 2200, 'pant_nike.jpg', 'Pant'),
(12, 'Coats', 2, 2, '<p>Coats...NorthFace</p>', 3200, 'north_face.jpg', 'coats'),
(13, 'Jacket', 2, 2, '<p>Jacket</p>', 3200, 's-l1600 (4).jpg', 'Jacket'),
(14, 'T-Shirt', 3, 1, '<p>T-Shirt Nike</p>', 900, 't-shirt_nike.jpg', 't shirts');

-- --------------------------------------------------------

--
-- Table structure for table `cloth_brand`
--

CREATE TABLE IF NOT EXISTS `cloth_brand` (
  `cloth_brand_id` int(11) NOT NULL AUTO_INCREMENT,
  `cloth_brand_title` varchar(255) NOT NULL,
  PRIMARY KEY (`cloth_brand_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `cloth_brand`
--

INSERT INTO `cloth_brand` (`cloth_brand_id`, `cloth_brand_title`) VALUES
(1, 'Nike'),
(2, 'North Face'),
(3, 'Nike'),
(4, 'North Face');

-- --------------------------------------------------------

--
-- Table structure for table `cloth_category`
--

CREATE TABLE IF NOT EXISTS `cloth_category` (
  `cloth_cata_id` int(11) NOT NULL AUTO_INCREMENT,
  `cloth_cata_title` varchar(255) NOT NULL,
  PRIMARY KEY (`cloth_cata_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `cloth_category`
--

INSERT INTO `cloth_category` (`cloth_cata_id`, `cloth_cata_title`) VALUES
(1, 'Pants'),
(2, 'Coats & Jackets'),
(3, 'T-Shirts'),
(4, 'Shoes');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `phone` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `customer_email` varchar(250) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `email_code` varchar(250) NOT NULL,
  `active` int(11) NOT NULL,
  `customer_ip` varchar(255) NOT NULL,
  `city` text NOT NULL,
  `region` text NOT NULL,
  `country` text NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `firstname`, `lastname`, `phone`, `username`, `customer_email`, `address`, `password`, `email_code`, `active`, `customer_ip`, `city`, `region`, `country`) VALUES
(39, 'Nishan', 'Shrestha', 2147483647, 'nishan180', 'n180nishan@gmail.com', 'Swoyambhu', 'f09debec734df68d109f6638759b0246', '0.22283', 1, '::1', '', '', ''),
(41, 'srikant', 'kandel', 2147483647, 'srikant', 'srikantkandel@gmail.com', 'ktm', 'c72a00974361b3e796979abfdd8175c3', '0.282782', 1, '::1', '', '', ''),
(42, 'shiva', 'ram', 898, 'sr', 'sr@gmail.com', 'ktm', 'e22428ccf96cda9674a939c209ad1000', '0.041264', 0, '::1', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `logged_user`
--

CREATE TABLE IF NOT EXISTS `logged_user` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `phone` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `customer_email` varchar(250) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `email_code` varchar(250) NOT NULL,
  `active` int(11) NOT NULL,
  `customer_ip` varchar(255) NOT NULL,
  `city` text NOT NULL,
  `region` text NOT NULL,
  `country` text NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_title` varchar(255) NOT NULL,
  `product_cata` int(11) NOT NULL,
  `product_brand` int(11) NOT NULL,
  `product_desc` text NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` varchar(255) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_title`, `product_cata`, `product_brand`, `product_desc`, `product_price`, `product_image`, `product_keywords`) VALUES
(1, 'Camera', 4, 2, '<p>camera ..sony brand</p>', 24000, 'camera_sony.png', 'camera'),
(2, 'Camera', 4, 1, '<p><b>HP brand camera</b></br> </br> The images may be individual </br>still photographs or </br> sequences of images constituting </br>videos or movies. </br>The camera is a </br>remote sensing device as</br> it senses subjects</br> without physical contact</p>', 28000, 'camera_hp.png', 'camera'),
(3, 'Laptop', 2, 3, '<p>Laptop ....DELL</p>', 64000, 'dell_laptop.JPG', 'Laptop'),
(4, 'TV', 1, 2, '<p>Sony brand TV.</p>', 65000, 'sony_tv1.jpg', 'TV'),
(5, 'Laptop', 2, 1, '<p>ACER laptop.</p>', 85000, 'acer_laptop.jpg', 'laptop'),
(6, 'Windows Mob', 3, 6, '<p>Windows mobile.</p>', 20000, 'windows_mob.jpg', 'mobile'),
(7, 'mobile samsung', 0, 4, '<p>samsung mobile</p>\r\n<p>&nbsp;</p>', 10000, 'samsung_mob.jpg', 'mobile'),
(8, 'beon', 3, 1, '<p>fuckin shit shirt</p>', 500, 'north_face.jpg', '243');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
