<?php

$con = mysqli_connect("localhost", "root", "", "sellerbuyer_2");
//error show garna ko lagi 
if(mysqli_connect_errno())
{
    echo 'Failed to connect MySQL'.mysqli_connect_error();
}
?>