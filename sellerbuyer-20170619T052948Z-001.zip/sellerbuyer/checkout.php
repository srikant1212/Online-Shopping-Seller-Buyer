<!DOCTYPE>
<?php
session_start();
include("functions/functions.php");
?>

<html>
    <head>
        
        <meta charset="UTF-8">
        <title>Seller Buyer</title>
        
        <link rel="stylesheet" href="styles/styles.css" media="all"/>
        
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
<link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>   
   




    </head>
    <body>
        
        <!-- sab vanda mathi ko navigation -->
          <nav class="navbar navbar-inverse navbar-fixed-top">
      
        <div class="navbar-header">
            <a class="navbar-brand" href="index.php">Seller Buyer Nepal Online shopping </a>
        </div>
        
         <form class="navbar-form navbar-right">
             
                <?php
                        if(!isset($_SESSION['customer_emailll']))
                        {
                            ?>
                        
            <div class="form-group">
              <input type="text" placeholder="Email" class="form-control">
            </div>
            <div class="form-group">
              <input type="password" placeholder="Password" class="form-control">
            </div>
            
     
         <button  type="submit" class="btn btn-success"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>
             <a href='checkout.php' style='color:white;'>Log In</a>
            </button>
           <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>
             <a href="customer_register.php"  style='color:white;'>Sign Up</a>
            </button>
                        <?php } ?>
                <?php
                        if(!isset($_SESSION['customer_emailll']))
                        {
                           echo "<a href='checkout.php' style='color:red ; text-align:left ;'></a>";
                          
                            
                           
                        }
                        else
                        {
                             echo "<a href='logout.php' style='color:red;'>Logout</a>";
                        }
                        ?>
             </form>
                       
          
       <!--/.navbar-collapse -->
      
    </nav>
       <!-- sab vanda mathi ko navigation -->  
        
        
        <div class="main_wrapper" >
            
            <div class="header_wrapper" > 
               <!-- <img id ="logo" src ="images/logo.gif"/>-->
                <img id="banner" src="images/banner.gif" />
                
            </div>
            
           
            <div class="menubar">
                <ul id="menu">
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="all_products.php">ALL PRODUCT</a></li>
                    <li><a href="cart.php">SHOPPING CART</a></li>
                    <li><a href="customer/my_account.php">MY ACCOUNT</a></li>
                  
                    <li><a href="contact_us.php">CONTACT US</a></li>
                </ul>           
<form class="navbar-form navbar-right" action="results.php" role="search">
  <div class="form-group">
    <input type="text" class="form-control" placeholder="Search a product">
  </div>
  <button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
</form>
      
  </ul>           
             
     </div>         
            
            <!--<div class="content_wrapper">-->
                <div id="content_area">       
                  <?php cart();?>  
                <div id="shopping_cart">
                    <span style="float: right"> <b style="color: greenyellow">Shopping cart</b>
                        Total Items:<b style="color: blue"><?php total_items();?></b> Total Price:<b style="color: blue">Rs.<?php total_price();?></b> 
                        <a href="cart.php">Go to Cart</a>
                    
                    </span>
                    
                </div>
                   
                    
                    <div id="products_box">
                       <?php 
                                              
                      // if(!isset($_GET['activated'])===TRUE)
                       //{
                       if(!isset($_SESSION['customer_emailll']))
                        {
                           include("customer_login.php");
                        }
                       else
                        {
                           include ("payment.php");
                        }
                       //}
                      ?>
                      
                  </div>
                        
                
                </div>

                <div id="sidebar">
                    <div id="sidebar_title">Women's Fashion</div>
                     <ul id="products">
                        <?php
                        //getWoman_Fashion();
                        getclothcata();
                        ?>
                   </ul>
                    <div id="sidebar_title">Clothing Brand</div>
                    <ul id="products">
                        <?php
                       // getMen_Fashion();
                        getclothbrand();
                        ?>
                   </ul>
                      <div id="sidebar_title">Categories</div>
                    <ul id="products">
                       <?php
                       getCats();
                       ?> 
                   </ul>
                    <div id="sidebar_title">Brands</div>
                    <ul id="products">
                       <?php
                       getBrands();
                       ?> 
                   </ul>
               
               
                
            </div>
            </div>
                
                
            
            
           
               <div class="footer">
                <ul id="footerr">
                
                    <li><a href="about_us.php">About Us</a></li>
                    <li><a href="conditions.php">Terms and Conditions</a></li>
                    <li><a href="contact_us.php">Contact Us</a></li>
                    <li><a href="support.php">Support</a></li>
                    
                </ul>
            </div>
        <!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    </body>
</html>
