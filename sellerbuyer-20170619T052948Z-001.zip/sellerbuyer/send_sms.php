<!DOCTYPE>
<?php
//session_start();
include("functions/functions.php");
//$_SESSION['qty']='';
?>
<HTML> 
<HEAD><TITLE>Send SMS</TITLE></HEAD> 
<BODY> 
<form method="post" action="send_sms.php"> 
<table border="1"> 
<tr> 
<td>Mobile Number:</td> 
<td><input type="text" name="phone" size="40"></td> 
</tr> 
<tr> 
<td valign="top">Text Message:</td> 
<td><textarea name="text" cols="80" rows="10"></textarea> 
</tr> 
<tr> 
<td colspan="2" align="center"> 
<input type="submit" value="Send"> 
</td> 
</tr> 
</table> 
</form> 
</BODY> 
</HTML> 
    <?php
    //$x   = SendSMS("1", 8800, "username", "password", "+9779811935541", "Test Message");
//echo $x;
if (isset($_REQUEST['phone'])) { 
   if (isset($_REQUEST['text'])) { 
      $x = SendSMS("localhost", 80, "username", "password", $_REQUEST['phone'], $_REQUEST['text']); 
      echo $x; 
   } 
   else { 
      echo "ERROR : Message not sent -- Text parameter is missing!\r\n"; 
   } 
} 
else { 
   echo "ERROR : Message not sent -- Phone parameter is missing!\r\n"; 
} 
?>