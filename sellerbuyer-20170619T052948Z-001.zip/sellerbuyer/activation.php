<?php
include("functions/functions.php");
if(isset($_GET['success']) ===TRUE && empty($_GET['success'])===TRUE){
    ?>
<h2><b>Thanks, we activated your account.</b></h2>
<h3>If you want to logged in </h3></br>
<h3>please put your username and password in home page of <b style="color: blue">Seller Buyer System</b></h3>
<?php
 echo "<a href='index.php?activated' style='color:red;'>HOME</a>"; ?>
<?php
    
}
elseif (isset($_GET['email']) && isset($_GET['email_code'])==TRUE) {
   
    $email=  trim($_GET['email']);
    $email_code=  trim($_GET['email_code']);
    
    if(email_exists($email)===FALSE)
    {
        $errors[]='Oops, something went wrong, we could not find your email address';
    }
    elseif ( activate($email,$email_code)===FALSE) {
        $errors[]='we had problems activating your account';
    }
    
    if(empty($errors)===FALSE){
        ?>
<h2>Oops........</h2>
<?php
echo output_errors($errors);
    }
    else{
        header('Location:activation.php?success');
        exit();
    }
    
}
 else {
    
header('Location:index.php');
exit();
 }
 ?>