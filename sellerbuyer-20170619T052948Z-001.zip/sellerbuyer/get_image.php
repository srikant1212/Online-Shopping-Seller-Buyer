<?php
include("includes/db.php");
global $con;
  $pro_id=$_GET['pro_id'];
    
    
    $get_pro="select * from products where product_id='$pro_id'";

    $run_pro=  mysqli_query($con, $get_pro);
    while ($row_pro =mysqli_fetch_array($run_pro))
    {
        $pro_id=$row_pro['product_id'];
        $pro_cat=$row_pro['product_cata'];
        $pro_brand=$row_pro['product_brand'];
        $pro_price=$row_pro['product_price'];
        $pro_title=$row_pro['product_title'];
        $pro_image=$row_pro['product_image'];
       
    }
    echo "<div>
     <img src='admin_area/products_images/$pro_image' width='300' height='400'/>
    </div>";
         
?>