<?php
include 'functions/functions.php';
 $total=0;
                                        global $con;
                                        $ip=  getIp();
                                        $sel_price= "select * from cart where ip_address='$ip'";
                                        $run_price= mysqli_query($con, $sel_price);
                                        while($p_price=  mysqli_fetch_array($run_price)){ 
                                            $pro_id=$p_price['p_id'];
                                            $pro_price="select * from products where product_id='$pro_id'";
                                            $run_pro_price=  mysqli_query($con, $pro_price);
                                            while ($pp_price=  mysqli_fetch_array($run_pro_price)){
                                                $product_price=array($pp_price['product_price']);  
                                                $product_title=$pp_price['product_title'];
                                                $product_image=$pp_price['product_image'];
                                                $single_price=$pp_price['product_price'];
                                                $values=  array_sum($product_price);
                                            $total=$total+$values;
                                            
                                            }
                                        }
                                ?>
    <!DOCTYPE>
    <html>
    <head>
        <title>Products Info</title>
        
        
    </head>
    <body>
        <div>
            <p><h2 align ="center">Products information</h2></p>
<table align ="center" width =1000">
<tr>
<th>Product Name</th>
<th>Product Price</th>
<th>Total_Price</th>
</tr>
 
<tr  align ="center" width =1000">
<td><?php echo $product_title;?> </td>
    <td><?php echo $single_price;?></td>
   
<td><?php echo $total;?></td>
</tr>
</table>  
        <div align ="center" >
        <button ><a href="send_pro_info_mail.php" style='float :left;' >Get Email</a></button>
         <button><a href="index.php" style='float :right;' >Home</a></button>
        </div>
</div> 
</body>
</html>