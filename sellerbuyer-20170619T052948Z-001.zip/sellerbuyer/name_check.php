<?php
if(isset($_POST["name2check"]) && $_POST["name2check"] != ""){
    include_once 'includes/db.php';
    $username = preg_replace('#[^a-z0-9]#i', '', $_POST['name2check']); 
    //$sql_uname_check = mysql_query("SELECT customer_id FROM customer WHERE username='$username' LIMIT 1"); 
    $sql_uname_check = "SELECT customer_id FROM customer WHERE username='$username' LIMIT 1";
	$run_sql=mysqli_query($con,$sql_uname_check);
	$uname_check = mysqli_num_rows($run_sql);
    if (strlen($username) < 4) {
	    echo '4 - 15 characters please';
	    exit();
    }
	if (is_numeric($username[0])) {
	    echo 'First character must be a letter';
	    exit();
    }
    if ($uname_check < 1) {
	    echo '<strong>' . $username . '</strong> is OK';
	    exit();
    } else {
	    echo '<strong>' . $username . '</strong> is taken';
	    exit();
    }
}
?>
<html>
<head>
<script>
function checkusername(){
	var status = document.getElementById("usernamestatus");
	var u = document.getElementById("uname").value;
	if(u != ""){
		status.innerHTML = 'checking...';
		var hr = new XMLHttpRequest();
		hr.open("POST", "name_check.php", true);
		hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		hr.onreadystatechange = function() {
			if(hr.readyState == 4 && hr.status == 200) {
				status.innerHTML = hr.responseText;
			}
		}
        var v = "name2check="+u;
        hr.send(v);
	}
}
</script>
</head>
<body>
<input type="text" name="uname" id="uname" onBlur="checkusername()" maxlength="15">
<span id="usernamestatus"></span>
</body>
</html>